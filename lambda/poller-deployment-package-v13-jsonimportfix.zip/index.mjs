import { GameLiftStreamsClient, GetStreamSessionCommand } from "@aws-sdk/client-gameliftstreams"; // Import v3 client and command
// Correctly import JSON with assertion for Node.js ESM
import { version as clientVersion } from "@aws-sdk/client-gameliftstreams/package.json" assert { type: "json" };
// Attempt to import smithy client version - might not be directly exposed
// import { version as smithyVersion } from "@smithy/smithy-client/package.json"; // Likely won't work directly

const region = process.env.AWS_REGION || 'eu-central-1'; // Default region

// Initialize the GameLiftStreams client (v3)
const gameliftStreamsClient = new GameLiftStreamsClient({ region });

console.log(`GameLift Streams SDK v3 Client initialized for region: ${region}`);
console.log(`Node.js version: ${process.version}`);
console.log(`@aws-sdk/client-gameliftstreams version: ${clientVersion}`);
// Log dependency versions if possible (may require reading package-lock.json or similar)
// console.log(`@smithy/core version: ...`); 

// Define CORS headers
const corsHeaders = {
    "Access-Control-Allow-Origin": "*", // Allow all origins (adjust in production)
    "Access-Control-Allow-Methods": "POST, OPTIONS", // Allow POST and OPTIONS
    "Access-Control-Allow-Headers": "Content-Type", // Allow Content-Type header
};

export const handler = async (event) => {
    console.log("--- Poller Lambda Handler v3 (Standard Command) ---"); // Updated log message
    console.log("Received event:", JSON.stringify(event, null, 2));

    // Handle CORS preflight OPTIONS request
    if (event?.requestContext?.http?.method === 'OPTIONS') {
        console.log("Handling OPTIONS preflight request");
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: "CORS preflight OK" }),
        };
    }

    // Extract streamSessionArn from the event body 
    let streamSessionArn;
    try {
        const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        streamSessionArn = body?.streamSessionArn;
        if (!streamSessionArn) {
            throw new Error("Missing 'streamSessionArn' in request body");
        }
    } catch (parseError) {
        console.error("Error parsing event body:", parseError);
        return {
            statusCode: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, 
            body: JSON.stringify({ message: "Invalid request body", error: parseError.message }),
        };
    }

    console.log(`Polling session status for ARN: ${streamSessionArn}`);

    // Construct command input using ONLY StreamSessionIdentifier
    const getCommandInput = {
        StreamSessionIdentifier: streamSessionArn, 
        // Identifier: streamSessionArn, // DO NOT provide Identifier
    }; 
    
    console.log("Sending GetStreamSessionCommand with input:", JSON.stringify(getCommandInput, null, 2));

    try {
        // Use the standard v3 Command pattern
        const getCommand = new GetStreamSessionCommand(getCommandInput);
        const response = await gameliftStreamsClient.send(getCommand);

        console.log(`GetStreamSessionCommand successful. Status: ${response?.Status}, RAW:`, JSON.stringify(response, null, 2));

        // Return the status and potentially the full response
        return {
            statusCode: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, 
            body: JSON.stringify({ 
                status: response.Status, 
                sessionInfo: response 
            }),
        };
    } catch (error) {
        console.error(`Error during GetStreamSessionCommand call for ARN ${streamSessionArn}:`, error);
       
        // Log specific error details
        console.error("Error Name:", error.name);
        console.error("Error Message:", error.message);
        if (error.$metadata) {
            console.error("Error Metadata:", JSON.stringify(error.$metadata));
        }
        if (error.stack) {
             console.error("Error Stack:", error.stack);
        }

        return {
            statusCode: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, 
            body: JSON.stringify({ 
                message: `Failed to get stream session status for ARN: ${streamSessionArn}`,
                errorName: error.name, 
                errorMessage: error.message
            }),
        };
    }
}; 