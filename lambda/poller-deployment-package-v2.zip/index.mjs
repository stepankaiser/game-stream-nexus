import { GameLiftStreamsClient, GetStreamSessionCommand } from "@aws-sdk/client-gameliftstreams";

// Initialize the GameLiftStreams client outside the handler for reuse
const region = process.env.AWS_REGION || "eu-central-1"; // Default to your region
const gameliftStreamsClient = new GameLiftStreamsClient({ region });

console.log(`GameLift Streams SDK Client initialized for region: ${region}`);

// Define CORS headers
const corsHeaders = {
    "Access-Control-Allow-Origin": "*", // Allow all origins (adjust in production)
    "Access-Control-Allow-Methods": "POST, OPTIONS", // Allow POST and OPTIONS
    "Access-Control-Allow-Headers": "Content-Type", // Allow Content-Type header
};

export const handler = async (event) => {
    console.log("--- Poller Lambda Handler v2 ---"); // Add version log
    console.log("Received event:", JSON.stringify(event, null, 2));

    // Handle CORS preflight OPTIONS request
    // Function URLs use event.requestContext.http.method
    if (event?.requestContext?.http?.method === 'OPTIONS') {
        console.log("Handling OPTIONS preflight request");
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: "CORS preflight OK" }),
        };
    }

    // --- Existing POST request handling --- 

    // Extract streamSessionArn from the event body (assuming it's passed in the body)
    let streamSessionArn;
    try {
        // Function URLs pass body as a string
        const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        streamSessionArn = body?.streamSessionArn;
        if (!streamSessionArn) {
            throw new Error("Missing 'streamSessionArn' in request body");
        }
    } catch (parseError) {
        console.error("Error parsing event body:", parseError);
        return {
            statusCode: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, // Add CORS headers
            body: JSON.stringify({ message: "Invalid request body", error: parseError.message }),
        };
    }

    console.log(`Polling session status for ARN: ${streamSessionArn}`);

    try {
        // --- Use 'StreamSessionIdentifier' as required by the API/SDK v3 --- 
        const getCommandInput = { StreamSessionIdentifier: streamSessionArn }; 
        console.log("Sending GetStreamSessionCommand with input:", JSON.stringify(getCommandInput, null, 2));
        const getCommand = new GetStreamSessionCommand(getCommandInput);

        const response = await gameliftStreamsClient.send(getCommand);
        console.log(`GetStreamSession successful. Status: ${response?.Status}, RAW:`, JSON.stringify(response, null, 2));

        // Return the full response details
        return {
            statusCode: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, // Add CORS headers
            body: JSON.stringify(response),
        };

    } catch (error) {
        console.error(`Error during GetStreamSession call for ARN ${streamSessionArn}:`, error);

        // Specific check for the inconsistent parameter error
        if (error.message.includes('HTTP label: Identifier') || error.message.includes('HTTP label: StreamSessionIdentifier')) {
            console.error("!!! Lambda encountered inconsistent parameter error during GetStreamSession.");
            // Potentially add logic here to retry with a different key if needed, or just report error.
        }

        return {
            statusCode: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, // Add CORS headers
            body: JSON.stringify({
                message: `Failed to get stream session status for ARN: ${streamSessionArn}`,
                errorName: error.name,
                errorMessage: error.message,
            }),
        };
    }
}; 