import { GameLiftStreamsClient } from "@aws-sdk/client-gameliftstreams"; // Import v3 client

const region = process.env.AWS_REGION || 'eu-central-1'; // Default region

// Initialize the GameLiftStreams client (v3)
const gameliftStreamsClient = new GameLiftStreamsClient({ region });

console.log(`GameLift Streams SDK v3 Client initialized for region: ${region}`);

// Define CORS headers
const corsHeaders = {
    "Access-Control-Allow-Origin": "*", // Allow all origins (adjust in production)
    "Access-Control-Allow-Methods": "POST, OPTIONS", // Allow POST and OPTIONS
    "Access-Control-Allow-Headers": "Content-Type", // Allow Content-Type header
};

export const handler = async (event) => {
    console.log("--- Poller Lambda Handler v2 (v3 Direct Call) ---"); 
    console.log("Received event:", JSON.stringify(event, null, 2));

    // Handle CORS preflight OPTIONS request
    if (event?.requestContext?.http?.method === 'OPTIONS') {
        console.log("Handling OPTIONS preflight request");
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: "CORS preflight OK" }),
        };
    }

    // Extract streamSessionArn from the event body 
    let streamSessionArn;
    try {
        const body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body;
        streamSessionArn = body?.streamSessionArn;
        if (!streamSessionArn) {
            throw new Error("Missing 'streamSessionArn' in request body");
        }
    } catch (parseError) {
        console.error("Error parsing event body:", parseError);
        return {
            statusCode: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, 
            body: JSON.stringify({ message: "Invalid request body", error: parseError.message }),
        };
    }

    console.log(`Polling session status for ARN: ${streamSessionArn}`);

    // Construct parameters for getStreamSession
    // Use the documented v3 parameter name
    const params = {
        StreamSessionIdentifier: streamSessionArn,
        // Try adding Identifier as well, since the sample app *might* implicitly rely on it?
        // Let's start without it first, matching the v3 docs.
        // Identifier: streamSessionArn 
    };
    
    console.log("Sending getStreamSession (v3 direct) with params:", JSON.stringify(params, null, 2));

    try {
        // Use the direct v3 call style (like sample app)
        // Add .promise() if required, although v3 might return a promise directly
        const response = await gameliftStreamsClient.getStreamSession(params);

        console.log(`GetStreamSession (v3 direct) successful. Status: ${response?.Status}, RAW:`, JSON.stringify(response, null, 2));

        // Return the status and potentially the full response
        return {
            statusCode: 200,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, 
            body: JSON.stringify({ 
                status: response.Status, 
                sessionInfo: response 
            }),
        };
    } catch (error) {
        console.error(`Error during GetStreamSession (v3 direct) call for ARN ${streamSessionArn}:`, error);
       
        // Check for the specific errors we've seen
        if (error.message && (error.message.includes('Identifier') || error.name === 'ValidationException')) {
             console.error("!!! Still encountering parameter issues with v3 direct call. Error Name:", error.name);
        }

        return {
            statusCode: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" }, 
            body: JSON.stringify({ 
                message: `Failed to get stream session status for ARN: ${streamSessionArn}`,
                errorName: error.name, 
                errorMessage: error.message
            }),
        };
    }
}; 