# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [3.758.0](https://github.com/aws/aws-sdk-js-v3/compare/v3.757.0...v3.758.0) (2025-02-27)


### Features

* **client-gameliftstreams:** update client ([3e4a903](https://github.com/aws/aws-sdk-js-v3/commit/3e4a903caeede49cb331196588a495d895ac325f))
