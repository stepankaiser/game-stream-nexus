"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GameLiftStreams = void 0;
const smithy_client_1 = require("@smithy/smithy-client");
const AddStreamGroupLocationsCommand_1 = require("./commands/AddStreamGroupLocationsCommand");
const AssociateApplicationsCommand_1 = require("./commands/AssociateApplicationsCommand");
const CreateApplicationCommand_1 = require("./commands/CreateApplicationCommand");
const CreateStreamGroupCommand_1 = require("./commands/CreateStreamGroupCommand");
const CreateStreamSessionConnectionCommand_1 = require("./commands/CreateStreamSessionConnectionCommand");
const DeleteApplicationCommand_1 = require("./commands/DeleteApplicationCommand");
const DeleteStreamGroupCommand_1 = require("./commands/DeleteStreamGroupCommand");
const DisassociateApplicationsCommand_1 = require("./commands/DisassociateApplicationsCommand");
const ExportStreamSessionFilesCommand_1 = require("./commands/ExportStreamSessionFilesCommand");
const GetApplicationCommand_1 = require("./commands/GetApplicationCommand");
const GetStreamGroupCommand_1 = require("./commands/GetStreamGroupCommand");
const GetStreamSessionCommand_1 = require("./commands/GetStreamSessionCommand");
const ListApplicationsCommand_1 = require("./commands/ListApplicationsCommand");
const ListStreamGroupsCommand_1 = require("./commands/ListStreamGroupsCommand");
const ListStreamSessionsByAccountCommand_1 = require("./commands/ListStreamSessionsByAccountCommand");
const ListStreamSessionsCommand_1 = require("./commands/ListStreamSessionsCommand");
const ListTagsForResourceCommand_1 = require("./commands/ListTagsForResourceCommand");
const RemoveStreamGroupLocationsCommand_1 = require("./commands/RemoveStreamGroupLocationsCommand");
const StartStreamSessionCommand_1 = require("./commands/StartStreamSessionCommand");
const TagResourceCommand_1 = require("./commands/TagResourceCommand");
const TerminateStreamSessionCommand_1 = require("./commands/TerminateStreamSessionCommand");
const UntagResourceCommand_1 = require("./commands/UntagResourceCommand");
const UpdateApplicationCommand_1 = require("./commands/UpdateApplicationCommand");
const UpdateStreamGroupCommand_1 = require("./commands/UpdateStreamGroupCommand");
const GameLiftStreamsClient_1 = require("./GameLiftStreamsClient");
const commands = {
    AddStreamGroupLocationsCommand: AddStreamGroupLocationsCommand_1.AddStreamGroupLocationsCommand,
    AssociateApplicationsCommand: AssociateApplicationsCommand_1.AssociateApplicationsCommand,
    CreateApplicationCommand: CreateApplicationCommand_1.CreateApplicationCommand,
    CreateStreamGroupCommand: CreateStreamGroupCommand_1.CreateStreamGroupCommand,
    CreateStreamSessionConnectionCommand: CreateStreamSessionConnectionCommand_1.CreateStreamSessionConnectionCommand,
    DeleteApplicationCommand: DeleteApplicationCommand_1.DeleteApplicationCommand,
    DeleteStreamGroupCommand: DeleteStreamGroupCommand_1.DeleteStreamGroupCommand,
    DisassociateApplicationsCommand: DisassociateApplicationsCommand_1.DisassociateApplicationsCommand,
    ExportStreamSessionFilesCommand: ExportStreamSessionFilesCommand_1.ExportStreamSessionFilesCommand,
    GetApplicationCommand: GetApplicationCommand_1.GetApplicationCommand,
    GetStreamGroupCommand: GetStreamGroupCommand_1.GetStreamGroupCommand,
    GetStreamSessionCommand: GetStreamSessionCommand_1.GetStreamSessionCommand,
    ListApplicationsCommand: ListApplicationsCommand_1.ListApplicationsCommand,
    ListStreamGroupsCommand: ListStreamGroupsCommand_1.ListStreamGroupsCommand,
    ListStreamSessionsCommand: ListStreamSessionsCommand_1.ListStreamSessionsCommand,
    ListStreamSessionsByAccountCommand: ListStreamSessionsByAccountCommand_1.ListStreamSessionsByAccountCommand,
    ListTagsForResourceCommand: ListTagsForResourceCommand_1.ListTagsForResourceCommand,
    RemoveStreamGroupLocationsCommand: RemoveStreamGroupLocationsCommand_1.RemoveStreamGroupLocationsCommand,
    StartStreamSessionCommand: StartStreamSessionCommand_1.StartStreamSessionCommand,
    TagResourceCommand: TagResourceCommand_1.TagResourceCommand,
    TerminateStreamSessionCommand: TerminateStreamSessionCommand_1.TerminateStreamSessionCommand,
    UntagResourceCommand: UntagResourceCommand_1.UntagResourceCommand,
    UpdateApplicationCommand: UpdateApplicationCommand_1.UpdateApplicationCommand,
    UpdateStreamGroupCommand: UpdateStreamGroupCommand_1.UpdateStreamGroupCommand,
};
class GameLiftStreams extends GameLiftStreamsClient_1.GameLiftStreamsClient {
}
exports.GameLiftStreams = GameLiftStreams;
(0, smithy_client_1.createAggregatedClient)(commands, GameLiftStreams);
