"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StartStreamSessionOutputFilterSensitiveLog = exports.StartStreamSessionInputFilterSensitiveLog = exports.GetStreamSessionOutputFilterSensitiveLog = exports.CreateStreamSessionConnectionOutputFilterSensitiveLog = exports.CreateStreamSessionConnectionInputFilterSensitiveLog = exports.StreamSessionStatusReason = exports.StreamSessionStatus = exports.Protocol = exports.ExportFilesStatus = exports.StreamGroupStatusReason = exports.StreamGroupStatus = exports.StreamClass = exports.ReplicationStatusType = exports.RuntimeEnvironmentType = exports.ConflictException = exports.ApplicationStatusReason = exports.ApplicationStatus = exports.ValidationException = exports.ThrottlingException = exports.ServiceQuotaExceededException = exports.ResourceNotFoundException = exports.InternalServerException = exports.StreamGroupLocationStatus = exports.AccessDeniedException = void 0;
const smithy_client_1 = require("@smithy/smithy-client");
const GameLiftStreamsServiceException_1 = require("./GameLiftStreamsServiceException");
class AccessDeniedException extends GameLiftStreamsServiceException_1.GameLiftStreamsServiceException {
    name = "AccessDeniedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
exports.AccessDeniedException = AccessDeniedException;
exports.StreamGroupLocationStatus = {
    ACTIVATING: "ACTIVATING",
    ACTIVE: "ACTIVE",
    ERROR: "ERROR",
    REMOVING: "REMOVING",
};
class InternalServerException extends GameLiftStreamsServiceException_1.GameLiftStreamsServiceException {
    name = "InternalServerException";
    $fault = "server";
    $retryable = {};
    Message;
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerException.prototype);
        this.Message = opts.Message;
    }
}
exports.InternalServerException = InternalServerException;
class ResourceNotFoundException extends GameLiftStreamsServiceException_1.GameLiftStreamsServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
exports.ResourceNotFoundException = ResourceNotFoundException;
class ServiceQuotaExceededException extends GameLiftStreamsServiceException_1.GameLiftStreamsServiceException {
    name = "ServiceQuotaExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ServiceQuotaExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceQuotaExceededException.prototype);
        this.Message = opts.Message;
    }
}
exports.ServiceQuotaExceededException = ServiceQuotaExceededException;
class ThrottlingException extends GameLiftStreamsServiceException_1.GameLiftStreamsServiceException {
    name = "ThrottlingException";
    $fault = "client";
    $retryable = {
        throttling: true,
    };
    Message;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.Message = opts.Message;
    }
}
exports.ThrottlingException = ThrottlingException;
class ValidationException extends GameLiftStreamsServiceException_1.GameLiftStreamsServiceException {
    name = "ValidationException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.Message = opts.Message;
    }
}
exports.ValidationException = ValidationException;
exports.ApplicationStatus = {
    DELETING: "DELETING",
    ERROR: "ERROR",
    INITIALIZED: "INITIALIZED",
    PROCESSING: "PROCESSING",
    READY: "READY",
};
exports.ApplicationStatusReason = {
    ACCESS_DENIED: "accessDenied",
    INTERNAL_ERROR: "internalError",
};
class ConflictException extends GameLiftStreamsServiceException_1.GameLiftStreamsServiceException {
    name = "ConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConflictException.prototype);
        this.Message = opts.Message;
    }
}
exports.ConflictException = ConflictException;
exports.RuntimeEnvironmentType = {
    PROTON: "PROTON",
    UBUNTU: "UBUNTU",
    WINDOWS: "WINDOWS",
};
exports.ReplicationStatusType = {
    COMPLETED: "COMPLETED",
    REPLICATING: "REPLICATING",
};
exports.StreamClass = {
    gen4n_high: "gen4n_high",
    gen4n_ultra: "gen4n_ultra",
    gen4n_win2022: "gen4n_win2022",
    gen5n_high: "gen5n_high",
    gen5n_ultra: "gen5n_ultra",
    gen5n_win2022: "gen5n_win2022",
};
exports.StreamGroupStatus = {
    ACTIVATING: "ACTIVATING",
    ACTIVE: "ACTIVE",
    ACTIVE_WITH_ERRORS: "ACTIVE_WITH_ERRORS",
    DELETING: "DELETING",
    ERROR: "ERROR",
    UPDATING_LOCATIONS: "UPDATING_LOCATIONS",
};
exports.StreamGroupStatusReason = {
    INTERNAL_ERROR: "internalError",
    NO_AVAILABLE_INSTANCES: "noAvailableInstances",
};
exports.ExportFilesStatus = {
    FAILED: "FAILED",
    PENDING: "PENDING",
    SUCCEEDED: "SUCCEEDED",
};
exports.Protocol = {
    WEBRTC: "WebRTC",
};
exports.StreamSessionStatus = {
    ACTIVATING: "ACTIVATING",
    ACTIVE: "ACTIVE",
    CONNECTED: "CONNECTED",
    ERROR: "ERROR",
    PENDING_CLIENT_RECONNECTION: "PENDING_CLIENT_RECONNECTION",
    RECONNECTING: "RECONNECTING",
    TERMINATED: "TERMINATED",
    TERMINATING: "TERMINATING",
};
exports.StreamSessionStatusReason = {
    APP_LOG_S3_DESTINATION_ERROR: "applicationLogS3DestinationError",
    INTERNAL_ERROR: "internalError",
    INVALID_SIGNAL_REQUEST: "invalidSignalRequest",
    PLACEMENT_TIMEOUT: "placementTimeout",
};
const CreateStreamSessionConnectionInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: smithy_client_1.SENSITIVE_STRING }),
});
exports.CreateStreamSessionConnectionInputFilterSensitiveLog = CreateStreamSessionConnectionInputFilterSensitiveLog;
const CreateStreamSessionConnectionOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalResponse && { SignalResponse: smithy_client_1.SENSITIVE_STRING }),
});
exports.CreateStreamSessionConnectionOutputFilterSensitiveLog = CreateStreamSessionConnectionOutputFilterSensitiveLog;
const GetStreamSessionOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: smithy_client_1.SENSITIVE_STRING }),
    ...(obj.SignalResponse && { SignalResponse: smithy_client_1.SENSITIVE_STRING }),
});
exports.GetStreamSessionOutputFilterSensitiveLog = GetStreamSessionOutputFilterSensitiveLog;
const StartStreamSessionInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: smithy_client_1.SENSITIVE_STRING }),
});
exports.StartStreamSessionInputFilterSensitiveLog = StartStreamSessionInputFilterSensitiveLog;
const StartStreamSessionOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: smithy_client_1.SENSITIVE_STRING }),
    ...(obj.SignalResponse && { SignalResponse: smithy_client_1.SENSITIVE_STRING }),
});
exports.StartStreamSessionOutputFilterSensitiveLog = StartStreamSessionOutputFilterSensitiveLog;
