"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paginateListApplications = void 0;
const core_1 = require("@smithy/core");
const ListApplicationsCommand_1 = require("../commands/ListApplicationsCommand");
const GameLiftStreamsClient_1 = require("../GameLiftStreamsClient");
exports.paginateListApplications = (0, core_1.createPaginator)(GameLiftStreamsClient_1.GameLiftStreamsClient, ListApplicationsCommand_1.ListApplicationsCommand, "NextToken", "NextToken", "MaxResults");
