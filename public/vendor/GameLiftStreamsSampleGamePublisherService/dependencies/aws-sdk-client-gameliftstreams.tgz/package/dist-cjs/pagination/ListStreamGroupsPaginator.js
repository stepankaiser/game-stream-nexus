"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paginateListStreamGroups = void 0;
const core_1 = require("@smithy/core");
const ListStreamGroupsCommand_1 = require("../commands/ListStreamGroupsCommand");
const GameLiftStreamsClient_1 = require("../GameLiftStreamsClient");
exports.paginateListStreamGroups = (0, core_1.createPaginator)(GameLiftStreamsClient_1.GameLiftStreamsClient, ListStreamGroupsCommand_1.ListStreamGroupsCommand, "NextToken", "NextToken", "MaxResults");
