"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paginateListStreamSessionsByAccount = void 0;
const core_1 = require("@smithy/core");
const ListStreamSessionsByAccountCommand_1 = require("../commands/ListStreamSessionsByAccountCommand");
const GameLiftStreamsClient_1 = require("../GameLiftStreamsClient");
exports.paginateListStreamSessionsByAccount = (0, core_1.createPaginator)(GameLiftStreamsClient_1.GameLiftStreamsClient, ListStreamSessionsByAccountCommand_1.ListStreamSessionsByAccountCommand, "NextToken", "NextToken", "MaxResults");
