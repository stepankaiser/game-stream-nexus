"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paginateListStreamSessions = void 0;
const core_1 = require("@smithy/core");
const ListStreamSessionsCommand_1 = require("../commands/ListStreamSessionsCommand");
const GameLiftStreamsClient_1 = require("../GameLiftStreamsClient");
exports.paginateListStreamSessions = (0, core_1.createPaginator)(GameLiftStreamsClient_1.GameLiftStreamsClient, ListStreamSessionsCommand_1.ListStreamSessionsCommand, "NextToken", "NextToken", "MaxResults");
