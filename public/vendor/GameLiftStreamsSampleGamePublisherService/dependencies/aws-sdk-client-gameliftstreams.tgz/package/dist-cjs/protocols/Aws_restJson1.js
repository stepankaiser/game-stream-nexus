"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.de_UpdateStreamGroupCommand = exports.de_UpdateApplicationCommand = exports.de_UntagResourceCommand = exports.de_TerminateStreamSessionCommand = exports.de_TagResourceCommand = exports.de_StartStreamSessionCommand = exports.de_RemoveStreamGroupLocationsCommand = exports.de_ListTagsForResourceCommand = exports.de_ListStreamSessionsByAccountCommand = exports.de_ListStreamSessionsCommand = exports.de_ListStreamGroupsCommand = exports.de_ListApplicationsCommand = exports.de_GetStreamSessionCommand = exports.de_GetStreamGroupCommand = exports.de_GetApplicationCommand = exports.de_ExportStreamSessionFilesCommand = exports.de_DisassociateApplicationsCommand = exports.de_DeleteStreamGroupCommand = exports.de_DeleteApplicationCommand = exports.de_CreateStreamSessionConnectionCommand = exports.de_CreateStreamGroupCommand = exports.de_CreateApplicationCommand = exports.de_AssociateApplicationsCommand = exports.de_AddStreamGroupLocationsCommand = exports.se_UpdateStreamGroupCommand = exports.se_UpdateApplicationCommand = exports.se_UntagResourceCommand = exports.se_TerminateStreamSessionCommand = exports.se_TagResourceCommand = exports.se_StartStreamSessionCommand = exports.se_RemoveStreamGroupLocationsCommand = exports.se_ListTagsForResourceCommand = exports.se_ListStreamSessionsByAccountCommand = exports.se_ListStreamSessionsCommand = exports.se_ListStreamGroupsCommand = exports.se_ListApplicationsCommand = exports.se_GetStreamSessionCommand = exports.se_GetStreamGroupCommand = exports.se_GetApplicationCommand = exports.se_ExportStreamSessionFilesCommand = exports.se_DisassociateApplicationsCommand = exports.se_DeleteStreamGroupCommand = exports.se_DeleteApplicationCommand = exports.se_CreateStreamSessionConnectionCommand = exports.se_CreateStreamGroupCommand = exports.se_CreateApplicationCommand = exports.se_AssociateApplicationsCommand = exports.se_AddStreamGroupLocationsCommand = void 0;
const core_1 = require("@aws-sdk/core");
const core_2 = require("@smithy/core");
const smithy_client_1 = require("@smithy/smithy-client");
const uuid_1 = require("uuid");
const GameLiftStreamsServiceException_1 = require("../models/GameLiftStreamsServiceException");
const models_0_1 = require("../models/models_0");
const se_AddStreamGroupLocationsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/locations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        LocationConfigurations: (_) => (0, smithy_client_1._json)(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_AddStreamGroupLocationsCommand = se_AddStreamGroupLocationsCommand;
const se_AssociateApplicationsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/associations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        ApplicationIdentifiers: (_) => (0, smithy_client_1._json)(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_AssociateApplicationsCommand = se_AssociateApplicationsCommand;
const se_CreateApplicationCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/applications");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        ApplicationLogOutputUri: [],
        ApplicationLogPaths: (_) => (0, smithy_client_1._json)(_),
        ApplicationSourceUri: [],
        ClientToken: [true, (_) => _ ?? (0, uuid_1.v4)()],
        Description: [],
        ExecutablePath: [],
        RuntimeEnvironment: (_) => (0, smithy_client_1._json)(_),
        Tags: (_) => (0, smithy_client_1._json)(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_CreateApplicationCommand = se_CreateApplicationCommand;
const se_CreateStreamGroupCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups");
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        ClientToken: [true, (_) => _ ?? (0, uuid_1.v4)()],
        DefaultApplicationIdentifier: [],
        Description: [],
        LocationConfigurations: (_) => (0, smithy_client_1._json)(_),
        StreamClass: [],
        Tags: (_) => (0, smithy_client_1._json)(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_CreateStreamGroupCommand = se_CreateStreamGroupCommand;
const se_CreateStreamSessionConnectionCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}/connections");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        ClientToken: [true, (_) => _ ?? (0, uuid_1.v4)()],
        SignalRequest: [],
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_CreateStreamSessionConnectionCommand = se_CreateStreamSessionConnectionCommand;
const se_DeleteApplicationCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/applications/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("DELETE").h(headers).b(body);
    return b.build();
};
exports.se_DeleteApplicationCommand = se_DeleteApplicationCommand;
const se_DeleteStreamGroupCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("DELETE").h(headers).b(body);
    return b.build();
};
exports.se_DeleteStreamGroupCommand = se_DeleteStreamGroupCommand;
const se_DisassociateApplicationsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/disassociations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        ApplicationIdentifiers: (_) => (0, smithy_client_1._json)(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_DisassociateApplicationsCommand = se_DisassociateApplicationsCommand;
const se_ExportStreamSessionFilesCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}/exportfiles");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        OutputUri: [],
    }));
    b.m("PUT").h(headers).b(body);
    return b.build();
};
exports.se_ExportStreamSessionFilesCommand = se_ExportStreamSessionFilesCommand;
const se_GetApplicationCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/applications/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
exports.se_GetApplicationCommand = se_GetApplicationCommand;
const se_GetStreamGroupCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
exports.se_GetStreamGroupCommand = se_GetStreamGroupCommand;
const se_GetStreamSessionCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
exports.se_GetStreamSessionCommand = se_GetStreamSessionCommand;
const se_ListApplicationsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/applications");
    const query = (0, smithy_client_1.map)({
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
exports.se_ListApplicationsCommand = se_ListApplicationsCommand;
const se_ListStreamGroupsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamgroups");
    const query = (0, smithy_client_1.map)({
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
exports.se_ListStreamGroupsCommand = se_ListStreamGroupsCommand;
const se_ListStreamSessionsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/streamsessions");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    const query = (0, smithy_client_1.map)({
        [_S]: [, input[_S]],
        [_EFS]: [, input[_EFS]],
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
exports.se_ListStreamSessionsCommand = se_ListStreamSessionsCommand;
const se_ListStreamSessionsByAccountCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamsessions");
    const query = (0, smithy_client_1.map)({
        [_S]: [, input[_S]],
        [_EFS]: [, input[_EFS]],
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
exports.se_ListStreamSessionsByAccountCommand = se_ListStreamSessionsByAccountCommand;
const se_ListTagsForResourceCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/tags/{ResourceArn}");
    b.p("ResourceArn", () => input.ResourceArn, "{ResourceArn}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
exports.se_ListTagsForResourceCommand = se_ListTagsForResourceCommand;
const se_RemoveStreamGroupLocationsCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/locations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    const query = (0, smithy_client_1.map)({
        [_l]: [(0, smithy_client_1.expectNonNull)(input.Locations, `Locations`) != null, () => input[_L] || []],
    });
    let body;
    b.m("DELETE").h(headers).q(query).b(body);
    return b.build();
};
exports.se_RemoveStreamGroupLocationsCommand = se_RemoveStreamGroupLocationsCommand;
const se_StartStreamSessionCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/streamsessions");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        AdditionalEnvironmentVariables: (_) => (0, smithy_client_1._json)(_),
        AdditionalLaunchArgs: (_) => (0, smithy_client_1._json)(_),
        ApplicationIdentifier: [],
        ClientToken: [true, (_) => _ ?? (0, uuid_1.v4)()],
        ConnectionTimeoutSeconds: [],
        Description: [],
        Locations: (_) => (0, smithy_client_1._json)(_),
        Protocol: [],
        SessionLengthSeconds: [],
        SignalRequest: [],
        UserId: [],
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_StartStreamSessionCommand = se_StartStreamSessionCommand;
const se_TagResourceCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/tags/{ResourceArn}");
    b.p("ResourceArn", () => input.ResourceArn, "{ResourceArn}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        Tags: (_) => (0, smithy_client_1._json)(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
exports.se_TagResourceCommand = se_TagResourceCommand;
const se_TerminateStreamSessionCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    b.m("DELETE").h(headers).b(body);
    return b.build();
};
exports.se_TerminateStreamSessionCommand = se_TerminateStreamSessionCommand;
const se_UntagResourceCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {};
    b.bp("/tags/{ResourceArn}");
    b.p("ResourceArn", () => input.ResourceArn, "{ResourceArn}", false);
    const query = (0, smithy_client_1.map)({
        [_tK]: [(0, smithy_client_1.expectNonNull)(input.TagKeys, `TagKeys`) != null, () => input[_TK] || []],
    });
    let body;
    b.m("DELETE").h(headers).q(query).b(body);
    return b.build();
};
exports.se_UntagResourceCommand = se_UntagResourceCommand;
const se_UpdateApplicationCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/applications/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        ApplicationLogOutputUri: [],
        ApplicationLogPaths: (_) => (0, smithy_client_1._json)(_),
        Description: [],
    }));
    b.m("PATCH").h(headers).b(body);
    return b.build();
};
exports.se_UpdateApplicationCommand = se_UpdateApplicationCommand;
const se_UpdateStreamGroupCommand = async (input, context) => {
    const b = (0, core_2.requestBuilder)(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        Description: [],
        LocationConfigurations: (_) => (0, smithy_client_1._json)(_),
    }));
    b.m("PATCH").h(headers).b(body);
    return b.build();
};
exports.se_UpdateStreamGroupCommand = se_UpdateStreamGroupCommand;
const de_AddStreamGroupLocationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Identifier: smithy_client_1.expectString,
        Locations: smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_AddStreamGroupLocationsCommand = de_AddStreamGroupLocationsCommand;
const de_AssociateApplicationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        ApplicationArns: smithy_client_1._json,
        Arn: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_AssociateApplicationsCommand = de_AssociateApplicationsCommand;
const de_CreateApplicationCommand = async (output, context) => {
    if (output.statusCode !== 201 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        ApplicationLogOutputUri: smithy_client_1.expectString,
        ApplicationLogPaths: smithy_client_1._json,
        ApplicationSourceUri: smithy_client_1.expectString,
        Arn: smithy_client_1.expectString,
        AssociatedStreamGroups: smithy_client_1._json,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Description: smithy_client_1.expectString,
        ExecutablePath: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        ReplicationStatuses: smithy_client_1._json,
        RuntimeEnvironment: smithy_client_1._json,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreateApplicationCommand = de_CreateApplicationCommand;
const de_CreateStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 201 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Arn: smithy_client_1.expectString,
        AssociatedApplications: smithy_client_1._json,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        DefaultApplication: smithy_client_1._json,
        Description: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        LocationStates: smithy_client_1._json,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
        StreamClass: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreateStreamGroupCommand = de_CreateStreamGroupCommand;
const de_CreateStreamSessionConnectionCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        SignalResponse: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_CreateStreamSessionConnectionCommand = de_CreateStreamSessionConnectionCommand;
const de_DeleteApplicationCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    await (0, smithy_client_1.collectBody)(output.body, context);
    return contents;
};
exports.de_DeleteApplicationCommand = de_DeleteApplicationCommand;
const de_DeleteStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    await (0, smithy_client_1.collectBody)(output.body, context);
    return contents;
};
exports.de_DeleteStreamGroupCommand = de_DeleteStreamGroupCommand;
const de_DisassociateApplicationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        ApplicationArns: smithy_client_1._json,
        Arn: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_DisassociateApplicationsCommand = de_DisassociateApplicationsCommand;
const de_ExportStreamSessionFilesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    await (0, smithy_client_1.collectBody)(output.body, context);
    return contents;
};
exports.de_ExportStreamSessionFilesCommand = de_ExportStreamSessionFilesCommand;
const de_GetApplicationCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        ApplicationLogOutputUri: smithy_client_1.expectString,
        ApplicationLogPaths: smithy_client_1._json,
        ApplicationSourceUri: smithy_client_1.expectString,
        Arn: smithy_client_1.expectString,
        AssociatedStreamGroups: smithy_client_1._json,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Description: smithy_client_1.expectString,
        ExecutablePath: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        ReplicationStatuses: smithy_client_1._json,
        RuntimeEnvironment: smithy_client_1._json,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetApplicationCommand = de_GetApplicationCommand;
const de_GetStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Arn: smithy_client_1.expectString,
        AssociatedApplications: smithy_client_1._json,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        DefaultApplication: smithy_client_1._json,
        Description: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        LocationStates: smithy_client_1._json,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
        StreamClass: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetStreamGroupCommand = de_GetStreamGroupCommand;
const de_GetStreamSessionCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        AdditionalEnvironmentVariables: smithy_client_1._json,
        AdditionalLaunchArgs: smithy_client_1._json,
        ApplicationArn: smithy_client_1.expectString,
        Arn: smithy_client_1.expectString,
        ConnectionTimeoutSeconds: smithy_client_1.expectInt32,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Description: smithy_client_1.expectString,
        ExportFilesMetadata: smithy_client_1._json,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Location: smithy_client_1.expectString,
        LogFileLocationUri: smithy_client_1.expectString,
        Protocol: smithy_client_1.expectString,
        SessionLengthSeconds: smithy_client_1.expectInt32,
        SignalRequest: smithy_client_1.expectString,
        SignalResponse: smithy_client_1.expectString,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
        StreamGroupId: smithy_client_1.expectString,
        UserId: smithy_client_1.expectString,
        WebSdkProtocolUrl: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetStreamSessionCommand = de_GetStreamSessionCommand;
const de_ListApplicationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Items: (_) => de_ApplicationSummaryList(_, context),
        NextToken: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListApplicationsCommand = de_ListApplicationsCommand;
const de_ListStreamGroupsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Items: (_) => de_StreamGroupSummaryList(_, context),
        NextToken: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListStreamGroupsCommand = de_ListStreamGroupsCommand;
const de_ListStreamSessionsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Items: (_) => de_StreamSessionSummaryList(_, context),
        NextToken: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListStreamSessionsCommand = de_ListStreamSessionsCommand;
const de_ListStreamSessionsByAccountCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Items: (_) => de_StreamSessionSummaryList(_, context),
        NextToken: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListStreamSessionsByAccountCommand = de_ListStreamSessionsByAccountCommand;
const de_ListTagsForResourceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Tags: smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ListTagsForResourceCommand = de_ListTagsForResourceCommand;
const de_RemoveStreamGroupLocationsCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    await (0, smithy_client_1.collectBody)(output.body, context);
    return contents;
};
exports.de_RemoveStreamGroupLocationsCommand = de_RemoveStreamGroupLocationsCommand;
const de_StartStreamSessionCommand = async (output, context) => {
    if (output.statusCode !== 201 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        AdditionalEnvironmentVariables: smithy_client_1._json,
        AdditionalLaunchArgs: smithy_client_1._json,
        ApplicationArn: smithy_client_1.expectString,
        Arn: smithy_client_1.expectString,
        ConnectionTimeoutSeconds: smithy_client_1.expectInt32,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Description: smithy_client_1.expectString,
        ExportFilesMetadata: smithy_client_1._json,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Location: smithy_client_1.expectString,
        LogFileLocationUri: smithy_client_1.expectString,
        Protocol: smithy_client_1.expectString,
        SessionLengthSeconds: smithy_client_1.expectInt32,
        SignalRequest: smithy_client_1.expectString,
        SignalResponse: smithy_client_1.expectString,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
        StreamGroupId: smithy_client_1.expectString,
        UserId: smithy_client_1.expectString,
        WebSdkProtocolUrl: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_StartStreamSessionCommand = de_StartStreamSessionCommand;
const de_TagResourceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    await (0, smithy_client_1.collectBody)(output.body, context);
    return contents;
};
exports.de_TagResourceCommand = de_TagResourceCommand;
const de_TerminateStreamSessionCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    await (0, smithy_client_1.collectBody)(output.body, context);
    return contents;
};
exports.de_TerminateStreamSessionCommand = de_TerminateStreamSessionCommand;
const de_UntagResourceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    await (0, smithy_client_1.collectBody)(output.body, context);
    return contents;
};
exports.de_UntagResourceCommand = de_UntagResourceCommand;
const de_UpdateApplicationCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        ApplicationLogOutputUri: smithy_client_1.expectString,
        ApplicationLogPaths: smithy_client_1._json,
        ApplicationSourceUri: smithy_client_1.expectString,
        Arn: smithy_client_1.expectString,
        AssociatedStreamGroups: smithy_client_1._json,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Description: smithy_client_1.expectString,
        ExecutablePath: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        ReplicationStatuses: smithy_client_1._json,
        RuntimeEnvironment: smithy_client_1._json,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_UpdateApplicationCommand = de_UpdateApplicationCommand;
const de_UpdateStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
    });
    const data = (0, smithy_client_1.expectNonNull)((0, smithy_client_1.expectObject)(await (0, core_1.parseJsonBody)(output.body, context)), "body");
    const doc = (0, smithy_client_1.take)(data, {
        Arn: smithy_client_1.expectString,
        AssociatedApplications: smithy_client_1._json,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        DefaultApplication: smithy_client_1._json,
        Description: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        LocationStates: smithy_client_1._json,
        Status: smithy_client_1.expectString,
        StatusReason: smithy_client_1.expectString,
        StreamClass: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_UpdateStreamGroupCommand = de_UpdateStreamGroupCommand;
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await (0, core_1.parseJsonErrorBody)(output.body, context),
    };
    const errorCode = (0, core_1.loadRestJsonErrorCode)(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.gameliftstreams#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.gameliftstreams#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.gameliftstreams#ResourceNotFoundException":
            throw await de_ResourceNotFoundExceptionRes(parsedOutput, context);
        case "ServiceQuotaExceededException":
        case "com.amazonaws.gameliftstreams#ServiceQuotaExceededException":
            throw await de_ServiceQuotaExceededExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.gameliftstreams#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.gameliftstreams#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        case "ConflictException":
        case "com.amazonaws.gameliftstreams#ConflictException":
            throw await de_ConflictExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode,
            });
    }
};
const throwDefaultError = (0, smithy_client_1.withBaseException)(GameLiftStreamsServiceException_1.GameLiftStreamsServiceException);
const de_AccessDeniedExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        Message: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.AccessDeniedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ConflictExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        Message: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ConflictException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_InternalServerExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        Message: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.InternalServerException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ResourceNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        Message: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ResourceNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ServiceQuotaExceededExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        Message: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ServiceQuotaExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ThrottlingExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        Message: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ThrottlingException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ValidationExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        Message: smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ApplicationSummary = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        Arn: smithy_client_1.expectString,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Description: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        RuntimeEnvironment: smithy_client_1._json,
        Status: smithy_client_1.expectString,
    });
};
const de_ApplicationSummaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ApplicationSummary(entry, context);
    });
    return retVal;
};
const de_StreamGroupSummary = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        Arn: smithy_client_1.expectString,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        DefaultApplication: smithy_client_1._json,
        Description: smithy_client_1.expectString,
        Id: smithy_client_1.expectString,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Status: smithy_client_1.expectString,
        StreamClass: smithy_client_1.expectString,
    });
};
const de_StreamGroupSummaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_StreamGroupSummary(entry, context);
    });
    return retVal;
};
const de_StreamSessionSummary = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        ApplicationArn: smithy_client_1.expectString,
        Arn: smithy_client_1.expectString,
        CreatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        ExportFilesMetadata: smithy_client_1._json,
        LastUpdatedAt: (_) => (0, smithy_client_1.expectNonNull)((0, smithy_client_1.parseEpochTimestamp)((0, smithy_client_1.expectNumber)(_))),
        Location: smithy_client_1.expectString,
        Protocol: smithy_client_1.expectString,
        Status: smithy_client_1.expectString,
        UserId: smithy_client_1.expectString,
    });
};
const de_StreamSessionSummaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_StreamSessionSummary(entry, context);
    });
    return retVal;
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => (0, smithy_client_1.collectBody)(streamBody, context).then((body) => context.utf8Encoder(body));
const _EFS = "ExportFilesStatus";
const _L = "Locations";
const _MR = "MaxResults";
const _NT = "NextToken";
const _S = "Status";
const _TK = "TagKeys";
const _l = "locations";
const _tK = "tagKeys";
