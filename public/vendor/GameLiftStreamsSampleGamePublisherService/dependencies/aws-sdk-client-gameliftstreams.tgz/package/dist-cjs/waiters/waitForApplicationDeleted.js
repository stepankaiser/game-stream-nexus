"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.waitUntilApplicationDeleted = exports.waitForApplicationDeleted = void 0;
const util_waiter_1 = require("@smithy/util-waiter");
const GetApplicationCommand_1 = require("../commands/GetApplicationCommand");
const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetApplicationCommand_1.GetApplicationCommand(input));
        reason = result;
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: util_waiter_1.WaiterState.SUCCESS, reason };
        }
    }
    return { state: util_waiter_1.WaiterState.RETRY, reason };
};
const waitForApplicationDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    return (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
};
exports.waitForApplicationDeleted = waitForApplicationDeleted;
const waitUntilApplicationDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    const result = await (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
    return (0, util_waiter_1.checkExceptions)(result);
};
exports.waitUntilApplicationDeleted = waitUntilApplicationDeleted;
