"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.waitUntilApplicationReady = exports.waitForApplicationReady = void 0;
const util_waiter_1 = require("@smithy/util-waiter");
const GetApplicationCommand_1 = require("../commands/GetApplicationCommand");
const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetApplicationCommand_1.GetApplicationCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "READY") {
                return { state: util_waiter_1.WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "ERROR") {
                return { state: util_waiter_1.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
    }
    return { state: util_waiter_1.WaiterState.RETRY, reason };
};
const waitForApplicationReady = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    return (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
};
exports.waitForApplicationReady = waitForApplicationReady;
const waitUntilApplicationReady = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    const result = await (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
    return (0, util_waiter_1.checkExceptions)(result);
};
exports.waitUntilApplicationReady = waitUntilApplicationReady;
