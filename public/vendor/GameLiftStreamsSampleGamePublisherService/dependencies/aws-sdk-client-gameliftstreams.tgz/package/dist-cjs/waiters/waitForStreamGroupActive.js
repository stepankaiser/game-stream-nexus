"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.waitUntilStreamGroupActive = exports.waitForStreamGroupActive = void 0;
const util_waiter_1 = require("@smithy/util-waiter");
const GetStreamGroupCommand_1 = require("../commands/GetStreamGroupCommand");
const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetStreamGroupCommand_1.GetStreamGroupCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "ACTIVE") {
                return { state: util_waiter_1.WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "ERROR") {
                return { state: util_waiter_1.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "ACTIVE_WITH_ERRORS") {
                return { state: util_waiter_1.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "DELETING") {
                return { state: util_waiter_1.WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
    }
    return { state: util_waiter_1.WaiterState.RETRY, reason };
};
const waitForStreamGroupActive = async (params, input) => {
    const serviceDefaults = { minDelay: 30, maxDelay: 3600 };
    return (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
};
exports.waitForStreamGroupActive = waitForStreamGroupActive;
const waitUntilStreamGroupActive = async (params, input) => {
    const serviceDefaults = { minDelay: 30, maxDelay: 3600 };
    const result = await (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
    return (0, util_waiter_1.checkExceptions)(result);
};
exports.waitUntilStreamGroupActive = waitUntilStreamGroupActive;
