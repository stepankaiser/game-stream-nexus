"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.waitUntilStreamGroupDeleted = exports.waitForStreamGroupDeleted = void 0;
const util_waiter_1 = require("@smithy/util-waiter");
const GetStreamGroupCommand_1 = require("../commands/GetStreamGroupCommand");
const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetStreamGroupCommand_1.GetStreamGroupCommand(input));
        reason = result;
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: util_waiter_1.WaiterState.SUCCESS, reason };
        }
    }
    return { state: util_waiter_1.WaiterState.RETRY, reason };
};
const waitForStreamGroupDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 30, maxDelay: 1800 };
    return (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
};
exports.waitForStreamGroupDeleted = waitForStreamGroupDeleted;
const waitUntilStreamGroupDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 30, maxDelay: 1800 };
    const result = await (0, util_waiter_1.createWaiter)({ ...serviceDefaults, ...params }, input, checkState);
    return (0, util_waiter_1.checkExceptions)(result);
};
exports.waitUntilStreamGroupDeleted = waitUntilStreamGroupDeleted;
