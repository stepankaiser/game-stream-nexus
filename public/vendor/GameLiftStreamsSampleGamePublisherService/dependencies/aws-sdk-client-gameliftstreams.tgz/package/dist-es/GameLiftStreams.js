import { createAggregatedClient } from "@smithy/smithy-client";
import { AddStreamGroupLocationsCommand, } from "./commands/AddStreamGroupLocationsCommand";
import { AssociateApplicationsCommand, } from "./commands/AssociateApplicationsCommand";
import { CreateApplicationCommand, } from "./commands/CreateApplicationCommand";
import { CreateStreamGroupCommand, } from "./commands/CreateStreamGroupCommand";
import { CreateStreamSessionConnectionCommand, } from "./commands/CreateStreamSessionConnectionCommand";
import { DeleteApplicationCommand, } from "./commands/DeleteApplicationCommand";
import { DeleteStreamGroupCommand, } from "./commands/DeleteStreamGroupCommand";
import { DisassociateApplicationsCommand, } from "./commands/DisassociateApplicationsCommand";
import { ExportStreamSessionFilesCommand, } from "./commands/ExportStreamSessionFilesCommand";
import { GetApplicationCommand, } from "./commands/GetApplicationCommand";
import { GetStreamGroupCommand, } from "./commands/GetStreamGroupCommand";
import { GetStreamSessionCommand, } from "./commands/GetStreamSessionCommand";
import { ListApplicationsCommand, } from "./commands/ListApplicationsCommand";
import { ListStreamGroupsCommand, } from "./commands/ListStreamGroupsCommand";
import { ListStreamSessionsByAccountCommand, } from "./commands/ListStreamSessionsByAccountCommand";
import { ListStreamSessionsCommand, } from "./commands/ListStreamSessionsCommand";
import { ListTagsForResourceCommand, } from "./commands/ListTagsForResourceCommand";
import { RemoveStreamGroupLocationsCommand, } from "./commands/RemoveStreamGroupLocationsCommand";
import { StartStreamSessionCommand, } from "./commands/StartStreamSessionCommand";
import { TagResourceCommand } from "./commands/TagResourceCommand";
import { TerminateStreamSessionCommand, } from "./commands/TerminateStreamSessionCommand";
import { UntagResourceCommand, } from "./commands/UntagResourceCommand";
import { UpdateApplicationCommand, } from "./commands/UpdateApplicationCommand";
import { UpdateStreamGroupCommand, } from "./commands/UpdateStreamGroupCommand";
import { GameLiftStreamsClient } from "./GameLiftStreamsClient";
const commands = {
    AddStreamGroupLocationsCommand,
    AssociateApplicationsCommand,
    CreateApplicationCommand,
    CreateStreamGroupCommand,
    CreateStreamSessionConnectionCommand,
    DeleteApplicationCommand,
    DeleteStreamGroupCommand,
    DisassociateApplicationsCommand,
    ExportStreamSessionFilesCommand,
    GetApplicationCommand,
    GetStreamGroupCommand,
    GetStreamSessionCommand,
    ListApplicationsCommand,
    ListStreamGroupsCommand,
    ListStreamSessionsCommand,
    ListStreamSessionsByAccountCommand,
    ListTagsForResourceCommand,
    RemoveStreamGroupLocationsCommand,
    StartStreamSessionCommand,
    TagResourceCommand,
    TerminateStreamSessionCommand,
    UntagResourceCommand,
    UpdateApplicationCommand,
    UpdateStreamGroupCommand,
};
export class GameLiftStreams extends GameLiftStreamsClient {
}
createAggregatedClient(commands, GameLiftStreams);
