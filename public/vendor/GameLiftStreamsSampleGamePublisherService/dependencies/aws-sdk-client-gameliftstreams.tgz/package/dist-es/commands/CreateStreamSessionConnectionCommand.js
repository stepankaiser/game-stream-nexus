import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { CreateStreamSessionConnectionInputFilterSensitiveLog, CreateStreamSessionConnectionOutputFilterSensitiveLog, } from "../models/models_0";
import { de_CreateStreamSessionConnectionCommand, se_CreateStreamSessionConnectionCommand, } from "../protocols/Aws_restJson1";
export { $Command };
export class CreateStreamSessionConnectionCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("GameLiftStreams", "CreateStreamSessionConnection", {})
    .n("GameLiftStreamsClient", "CreateStreamSessionConnectionCommand")
    .f(CreateStreamSessionConnectionInputFilterSensitiveLog, CreateStreamSessionConnectionOutputFilterSensitiveLog)
    .ser(se_CreateStreamSessionConnectionCommand)
    .de(de_CreateStreamSessionConnectionCommand)
    .build() {
}
