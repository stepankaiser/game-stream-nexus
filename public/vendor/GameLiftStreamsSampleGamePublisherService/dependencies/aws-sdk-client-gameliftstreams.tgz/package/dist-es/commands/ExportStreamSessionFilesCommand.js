import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { de_ExportStreamSessionFilesCommand, se_ExportStreamSessionFilesCommand } from "../protocols/Aws_restJson1";
export { $Command };
export class ExportStreamSessionFilesCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("GameLiftStreams", "ExportStreamSessionFiles", {})
    .n("GameLiftStreamsClient", "ExportStreamSessionFilesCommand")
    .f(void 0, void 0)
    .ser(se_ExportStreamSessionFilesCommand)
    .de(de_ExportStreamSessionFilesCommand)
    .build() {
}
