import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { de_GetApplicationCommand, se_GetApplicationCommand } from "../protocols/Aws_restJson1";
export { $Command };
export class GetApplicationCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("GameLiftStreams", "GetApplication", {})
    .n("GameLiftStreamsClient", "GetApplicationCommand")
    .f(void 0, void 0)
    .ser(se_GetApplicationCommand)
    .de(de_GetApplicationCommand)
    .build() {
}
