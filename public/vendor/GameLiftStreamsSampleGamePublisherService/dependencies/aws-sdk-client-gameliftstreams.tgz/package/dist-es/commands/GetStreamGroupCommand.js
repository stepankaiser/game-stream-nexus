import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { de_GetStreamGroupCommand, se_GetStreamGroupCommand } from "../protocols/Aws_restJson1";
export { $Command };
export class GetStreamGroupCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("GameLiftStreams", "GetStreamGroup", {})
    .n("GameLiftStreamsClient", "GetStreamGroupCommand")
    .f(void 0, void 0)
    .ser(se_GetStreamGroupCommand)
    .de(de_GetStreamGroupCommand)
    .build() {
}
