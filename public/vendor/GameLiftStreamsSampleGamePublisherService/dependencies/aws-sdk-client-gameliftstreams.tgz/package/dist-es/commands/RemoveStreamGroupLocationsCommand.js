import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { de_RemoveStreamGroupLocationsCommand, se_RemoveStreamGroupLocationsCommand } from "../protocols/Aws_restJson1";
export { $Command };
export class RemoveStreamGroupLocationsCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("GameLiftStreams", "RemoveStreamGroupLocations", {})
    .n("GameLiftStreamsClient", "RemoveStreamGroupLocationsCommand")
    .f(void 0, void 0)
    .ser(se_RemoveStreamGroupLocationsCommand)
    .de(de_RemoveStreamGroupLocationsCommand)
    .build() {
}
