import { getEndpointPlugin } from "@smithy/middleware-endpoint";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { commonParams } from "../endpoint/EndpointParameters";
import { StartStreamSessionInputFilterSensitiveLog, StartStreamSessionOutputFilterSensitiveLog, } from "../models/models_0";
import { de_StartStreamSessionCommand, se_StartStreamSessionCommand } from "../protocols/Aws_restJson1";
export { $Command };
export class StartStreamSessionCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [
        getSerdePlugin(config, this.serialize, this.deserialize),
        getEndpointPlugin(config, Command.getEndpointParameterInstructions()),
    ];
})
    .s("GameLiftStreams", "StartStreamSession", {})
    .n("GameLiftStreamsClient", "StartStreamSessionCommand")
    .f(StartStreamSessionInputFilterSensitiveLog, StartStreamSessionOutputFilterSensitiveLog)
    .ser(se_StartStreamSessionCommand)
    .de(de_StartStreamSessionCommand)
    .build() {
}
