import { SENSITIVE_STRING } from "@smithy/smithy-client";
import { GameLiftStreamsServiceException as __BaseException } from "./GameLiftStreamsServiceException";
export class AccessDeniedException extends __BaseException {
    name = "AccessDeniedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
export const StreamGroupLocationStatus = {
    ACTIVATING: "ACTIVATING",
    ACTIVE: "ACTIVE",
    ERROR: "ERROR",
    REMOVING: "REMOVING",
};
export class InternalServerException extends __BaseException {
    name = "InternalServerException";
    $fault = "server";
    $retryable = {};
    Message;
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalServerException.prototype);
        this.Message = opts.Message;
    }
}
export class ResourceNotFoundException extends __BaseException {
    name = "ResourceNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
        this.Message = opts.Message;
    }
}
export class ServiceQuotaExceededException extends __BaseException {
    name = "ServiceQuotaExceededException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ServiceQuotaExceededException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ServiceQuotaExceededException.prototype);
        this.Message = opts.Message;
    }
}
export class ThrottlingException extends __BaseException {
    name = "ThrottlingException";
    $fault = "client";
    $retryable = {
        throttling: true,
    };
    Message;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.Message = opts.Message;
    }
}
export class ValidationException extends __BaseException {
    name = "ValidationException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.Message = opts.Message;
    }
}
export const ApplicationStatus = {
    DELETING: "DELETING",
    ERROR: "ERROR",
    INITIALIZED: "INITIALIZED",
    PROCESSING: "PROCESSING",
    READY: "READY",
};
export const ApplicationStatusReason = {
    ACCESS_DENIED: "accessDenied",
    INTERNAL_ERROR: "internalError",
};
export class ConflictException extends __BaseException {
    name = "ConflictException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ConflictException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ConflictException.prototype);
        this.Message = opts.Message;
    }
}
export const RuntimeEnvironmentType = {
    PROTON: "PROTON",
    UBUNTU: "UBUNTU",
    WINDOWS: "WINDOWS",
};
export const ReplicationStatusType = {
    COMPLETED: "COMPLETED",
    REPLICATING: "REPLICATING",
};
export const StreamClass = {
    gen4n_high: "gen4n_high",
    gen4n_ultra: "gen4n_ultra",
    gen4n_win2022: "gen4n_win2022",
    gen5n_high: "gen5n_high",
    gen5n_ultra: "gen5n_ultra",
    gen5n_win2022: "gen5n_win2022",
};
export const StreamGroupStatus = {
    ACTIVATING: "ACTIVATING",
    ACTIVE: "ACTIVE",
    ACTIVE_WITH_ERRORS: "ACTIVE_WITH_ERRORS",
    DELETING: "DELETING",
    ERROR: "ERROR",
    UPDATING_LOCATIONS: "UPDATING_LOCATIONS",
};
export const StreamGroupStatusReason = {
    INTERNAL_ERROR: "internalError",
    NO_AVAILABLE_INSTANCES: "noAvailableInstances",
};
export const ExportFilesStatus = {
    FAILED: "FAILED",
    PENDING: "PENDING",
    SUCCEEDED: "SUCCEEDED",
};
export const Protocol = {
    WEBRTC: "WebRTC",
};
export const StreamSessionStatus = {
    ACTIVATING: "ACTIVATING",
    ACTIVE: "ACTIVE",
    CONNECTED: "CONNECTED",
    ERROR: "ERROR",
    PENDING_CLIENT_RECONNECTION: "PENDING_CLIENT_RECONNECTION",
    RECONNECTING: "RECONNECTING",
    TERMINATED: "TERMINATED",
    TERMINATING: "TERMINATING",
};
export const StreamSessionStatusReason = {
    APP_LOG_S3_DESTINATION_ERROR: "applicationLogS3DestinationError",
    INTERNAL_ERROR: "internalError",
    INVALID_SIGNAL_REQUEST: "invalidSignalRequest",
    PLACEMENT_TIMEOUT: "placementTimeout",
};
export const CreateStreamSessionConnectionInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: SENSITIVE_STRING }),
});
export const CreateStreamSessionConnectionOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalResponse && { SignalResponse: SENSITIVE_STRING }),
});
export const GetStreamSessionOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: SENSITIVE_STRING }),
    ...(obj.SignalResponse && { SignalResponse: SENSITIVE_STRING }),
});
export const StartStreamSessionInputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: SENSITIVE_STRING }),
});
export const StartStreamSessionOutputFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SignalRequest && { SignalRequest: SENSITIVE_STRING }),
    ...(obj.SignalResponse && { SignalResponse: SENSITIVE_STRING }),
});
