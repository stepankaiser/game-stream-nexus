import { createPaginator } from "@smithy/core";
import { ListApplicationsCommand, } from "../commands/ListApplicationsCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
export const paginateListApplications = createPaginator(GameLiftStreamsClient, ListApplicationsCommand, "NextToken", "NextToken", "MaxResults");
