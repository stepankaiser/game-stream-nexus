import { createPaginator } from "@smithy/core";
import { ListStreamGroupsCommand, } from "../commands/ListStreamGroupsCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
export const paginateListStreamGroups = createPaginator(GameLiftStreamsClient, ListStreamGroupsCommand, "NextToken", "NextToken", "MaxResults");
