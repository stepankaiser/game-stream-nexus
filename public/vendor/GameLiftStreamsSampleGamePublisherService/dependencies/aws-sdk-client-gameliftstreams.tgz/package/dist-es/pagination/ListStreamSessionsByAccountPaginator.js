import { createPaginator } from "@smithy/core";
import { ListStreamSessionsByAccountCommand, } from "../commands/ListStreamSessionsByAccountCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
export const paginateListStreamSessionsByAccount = createPaginator(GameLiftStreamsClient, ListStreamSessionsByAccountCommand, "NextToken", "NextToken", "MaxResults");
