import { createPaginator } from "@smithy/core";
import { ListStreamSessionsCommand, } from "../commands/ListStreamSessionsCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
export const paginateListStreamSessions = createPaginator(GameLiftStreamsClient, ListStreamSessionsCommand, "NextToken", "NextToken", "MaxResults");
