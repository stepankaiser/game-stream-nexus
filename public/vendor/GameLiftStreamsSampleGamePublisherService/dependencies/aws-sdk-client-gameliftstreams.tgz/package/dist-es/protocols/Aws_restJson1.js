import { loadRestJsonErrorCode, parseJsonBody as parseBody, parseJsonErrorBody as parseErrorBody } from "@aws-sdk/core";
import { requestBuilder as rb } from "@smithy/core";
import { _json, collectBody, decorateServiceException as __decorateServiceException, expectInt32 as __expectInt32, expectNonNull as __expectNonNull, expectNumber as __expectNumber, expectObject as __expectObject, expectString as __expectString, map, parseEpochTimestamp as __parseEpochTimestamp, take, withBaseException, } from "@smithy/smithy-client";
import { v4 as generateIdempotencyToken } from "uuid";
import { GameLiftStreamsServiceException as __BaseException } from "../models/GameLiftStreamsServiceException";
import { AccessDeniedException, ConflictException, InternalServerException, ResourceNotFoundException, ServiceQuotaExceededException, ThrottlingException, ValidationException, } from "../models/models_0";
export const se_AddStreamGroupLocationsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/locations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        LocationConfigurations: (_) => _json(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_AssociateApplicationsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/associations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        ApplicationIdentifiers: (_) => _json(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_CreateApplicationCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/applications");
    let body;
    body = JSON.stringify(take(input, {
        ApplicationLogOutputUri: [],
        ApplicationLogPaths: (_) => _json(_),
        ApplicationSourceUri: [],
        ClientToken: [true, (_) => _ ?? generateIdempotencyToken()],
        Description: [],
        ExecutablePath: [],
        RuntimeEnvironment: (_) => _json(_),
        Tags: (_) => _json(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_CreateStreamGroupCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups");
    let body;
    body = JSON.stringify(take(input, {
        ClientToken: [true, (_) => _ ?? generateIdempotencyToken()],
        DefaultApplicationIdentifier: [],
        Description: [],
        LocationConfigurations: (_) => _json(_),
        StreamClass: [],
        Tags: (_) => _json(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_CreateStreamSessionConnectionCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}/connections");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        ClientToken: [true, (_) => _ ?? generateIdempotencyToken()],
        SignalRequest: [],
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_DeleteApplicationCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/applications/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("DELETE").h(headers).b(body);
    return b.build();
};
export const se_DeleteStreamGroupCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("DELETE").h(headers).b(body);
    return b.build();
};
export const se_DisassociateApplicationsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/disassociations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        ApplicationIdentifiers: (_) => _json(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_ExportStreamSessionFilesCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}/exportfiles");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        OutputUri: [],
    }));
    b.m("PUT").h(headers).b(body);
    return b.build();
};
export const se_GetApplicationCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/applications/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
export const se_GetStreamGroupCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
export const se_GetStreamSessionCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
export const se_ListApplicationsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/applications");
    const query = map({
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
export const se_ListStreamGroupsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamgroups");
    const query = map({
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
export const se_ListStreamSessionsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/streamsessions");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    const query = map({
        [_S]: [, input[_S]],
        [_EFS]: [, input[_EFS]],
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
export const se_ListStreamSessionsByAccountCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamsessions");
    const query = map({
        [_S]: [, input[_S]],
        [_EFS]: [, input[_EFS]],
        [_NT]: [, input[_NT]],
        [_MR]: [() => input.MaxResults !== void 0, () => input[_MR].toString()],
    });
    let body;
    b.m("GET").h(headers).q(query).b(body);
    return b.build();
};
export const se_ListTagsForResourceCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/tags/{ResourceArn}");
    b.p("ResourceArn", () => input.ResourceArn, "{ResourceArn}", false);
    let body;
    b.m("GET").h(headers).b(body);
    return b.build();
};
export const se_RemoveStreamGroupLocationsCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/locations");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    const query = map({
        [_l]: [__expectNonNull(input.Locations, `Locations`) != null, () => input[_L] || []],
    });
    let body;
    b.m("DELETE").h(headers).q(query).b(body);
    return b.build();
};
export const se_StartStreamSessionCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}/streamsessions");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        AdditionalEnvironmentVariables: (_) => _json(_),
        AdditionalLaunchArgs: (_) => _json(_),
        ApplicationIdentifier: [],
        ClientToken: [true, (_) => _ ?? generateIdempotencyToken()],
        ConnectionTimeoutSeconds: [],
        Description: [],
        Locations: (_) => _json(_),
        Protocol: [],
        SessionLengthSeconds: [],
        SignalRequest: [],
        UserId: [],
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_TagResourceCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/tags/{ResourceArn}");
    b.p("ResourceArn", () => input.ResourceArn, "{ResourceArn}", false);
    let body;
    body = JSON.stringify(take(input, {
        Tags: (_) => _json(_),
    }));
    b.m("POST").h(headers).b(body);
    return b.build();
};
export const se_TerminateStreamSessionCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/streamgroups/{Identifier}/streamsessions/{StreamSessionIdentifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    b.p("StreamSessionIdentifier", () => input.StreamSessionIdentifier, "{StreamSessionIdentifier}", false);
    let body;
    b.m("DELETE").h(headers).b(body);
    return b.build();
};
export const se_UntagResourceCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {};
    b.bp("/tags/{ResourceArn}");
    b.p("ResourceArn", () => input.ResourceArn, "{ResourceArn}", false);
    const query = map({
        [_tK]: [__expectNonNull(input.TagKeys, `TagKeys`) != null, () => input[_TK] || []],
    });
    let body;
    b.m("DELETE").h(headers).q(query).b(body);
    return b.build();
};
export const se_UpdateApplicationCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/applications/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        ApplicationLogOutputUri: [],
        ApplicationLogPaths: (_) => _json(_),
        Description: [],
    }));
    b.m("PATCH").h(headers).b(body);
    return b.build();
};
export const se_UpdateStreamGroupCommand = async (input, context) => {
    const b = rb(input, context);
    const headers = {
        "content-type": "application/json",
    };
    b.bp("/streamgroups/{Identifier}");
    b.p("Identifier", () => input.Identifier, "{Identifier}", false);
    let body;
    body = JSON.stringify(take(input, {
        Description: [],
        LocationConfigurations: (_) => _json(_),
    }));
    b.m("PATCH").h(headers).b(body);
    return b.build();
};
export const de_AddStreamGroupLocationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Identifier: __expectString,
        Locations: _json,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_AssociateApplicationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        ApplicationArns: _json,
        Arn: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreateApplicationCommand = async (output, context) => {
    if (output.statusCode !== 201 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        ApplicationLogOutputUri: __expectString,
        ApplicationLogPaths: _json,
        ApplicationSourceUri: __expectString,
        Arn: __expectString,
        AssociatedStreamGroups: _json,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Description: __expectString,
        ExecutablePath: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        ReplicationStatuses: _json,
        RuntimeEnvironment: _json,
        Status: __expectString,
        StatusReason: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreateStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 201 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Arn: __expectString,
        AssociatedApplications: _json,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        DefaultApplication: _json,
        Description: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        LocationStates: _json,
        Status: __expectString,
        StatusReason: __expectString,
        StreamClass: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_CreateStreamSessionConnectionCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        SignalResponse: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_DeleteApplicationCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_DeleteStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_DisassociateApplicationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        ApplicationArns: _json,
        Arn: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ExportStreamSessionFilesCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_GetApplicationCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        ApplicationLogOutputUri: __expectString,
        ApplicationLogPaths: _json,
        ApplicationSourceUri: __expectString,
        Arn: __expectString,
        AssociatedStreamGroups: _json,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Description: __expectString,
        ExecutablePath: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        ReplicationStatuses: _json,
        RuntimeEnvironment: _json,
        Status: __expectString,
        StatusReason: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Arn: __expectString,
        AssociatedApplications: _json,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        DefaultApplication: _json,
        Description: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        LocationStates: _json,
        Status: __expectString,
        StatusReason: __expectString,
        StreamClass: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_GetStreamSessionCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        AdditionalEnvironmentVariables: _json,
        AdditionalLaunchArgs: _json,
        ApplicationArn: __expectString,
        Arn: __expectString,
        ConnectionTimeoutSeconds: __expectInt32,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Description: __expectString,
        ExportFilesMetadata: _json,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Location: __expectString,
        LogFileLocationUri: __expectString,
        Protocol: __expectString,
        SessionLengthSeconds: __expectInt32,
        SignalRequest: __expectString,
        SignalResponse: __expectString,
        Status: __expectString,
        StatusReason: __expectString,
        StreamGroupId: __expectString,
        UserId: __expectString,
        WebSdkProtocolUrl: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListApplicationsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Items: (_) => de_ApplicationSummaryList(_, context),
        NextToken: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListStreamGroupsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Items: (_) => de_StreamGroupSummaryList(_, context),
        NextToken: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListStreamSessionsCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Items: (_) => de_StreamSessionSummaryList(_, context),
        NextToken: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListStreamSessionsByAccountCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Items: (_) => de_StreamSessionSummaryList(_, context),
        NextToken: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_ListTagsForResourceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Tags: _json,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_RemoveStreamGroupLocationsCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_StartStreamSessionCommand = async (output, context) => {
    if (output.statusCode !== 201 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        AdditionalEnvironmentVariables: _json,
        AdditionalLaunchArgs: _json,
        ApplicationArn: __expectString,
        Arn: __expectString,
        ConnectionTimeoutSeconds: __expectInt32,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Description: __expectString,
        ExportFilesMetadata: _json,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Location: __expectString,
        LogFileLocationUri: __expectString,
        Protocol: __expectString,
        SessionLengthSeconds: __expectInt32,
        SignalRequest: __expectString,
        SignalResponse: __expectString,
        Status: __expectString,
        StatusReason: __expectString,
        StreamGroupId: __expectString,
        UserId: __expectString,
        WebSdkProtocolUrl: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_TagResourceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_TerminateStreamSessionCommand = async (output, context) => {
    if (output.statusCode !== 204 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_UntagResourceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    await collectBody(output.body, context);
    return contents;
};
export const de_UpdateApplicationCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        ApplicationLogOutputUri: __expectString,
        ApplicationLogPaths: _json,
        ApplicationSourceUri: __expectString,
        Arn: __expectString,
        AssociatedStreamGroups: _json,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Description: __expectString,
        ExecutablePath: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        ReplicationStatuses: _json,
        RuntimeEnvironment: _json,
        Status: __expectString,
        StatusReason: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
export const de_UpdateStreamGroupCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_CommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
    });
    const data = __expectNonNull(__expectObject(await parseBody(output.body, context)), "body");
    const doc = take(data, {
        Arn: __expectString,
        AssociatedApplications: _json,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        DefaultApplication: _json,
        Description: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        LocationStates: _json,
        Status: __expectString,
        StatusReason: __expectString,
        StreamClass: __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
const de_CommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context),
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.gameliftstreams#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.gameliftstreams#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ResourceNotFoundException":
        case "com.amazonaws.gameliftstreams#ResourceNotFoundException":
            throw await de_ResourceNotFoundExceptionRes(parsedOutput, context);
        case "ServiceQuotaExceededException":
        case "com.amazonaws.gameliftstreams#ServiceQuotaExceededException":
            throw await de_ServiceQuotaExceededExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.gameliftstreams#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.gameliftstreams#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        case "ConflictException":
        case "com.amazonaws.gameliftstreams#ConflictException":
            throw await de_ConflictExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode,
            });
    }
};
const throwDefaultError = withBaseException(__BaseException);
const de_AccessDeniedExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        Message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new AccessDeniedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ConflictExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        Message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ConflictException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InternalServerExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        Message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new InternalServerException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ResourceNotFoundExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        Message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ResourceNotFoundException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ServiceQuotaExceededExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        Message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ServiceQuotaExceededException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ThrottlingExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        Message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ThrottlingException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ValidationExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        Message: __expectString,
    });
    Object.assign(contents, doc);
    const exception = new ValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents,
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ApplicationSummary = (output, context) => {
    return take(output, {
        Arn: __expectString,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Description: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        RuntimeEnvironment: _json,
        Status: __expectString,
    });
};
const de_ApplicationSummaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_ApplicationSummary(entry, context);
    });
    return retVal;
};
const de_StreamGroupSummary = (output, context) => {
    return take(output, {
        Arn: __expectString,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        DefaultApplication: _json,
        Description: __expectString,
        Id: __expectString,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Status: __expectString,
        StreamClass: __expectString,
    });
};
const de_StreamGroupSummaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_StreamGroupSummary(entry, context);
    });
    return retVal;
};
const de_StreamSessionSummary = (output, context) => {
    return take(output, {
        ApplicationArn: __expectString,
        Arn: __expectString,
        CreatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        ExportFilesMetadata: _json,
        LastUpdatedAt: (_) => __expectNonNull(__parseEpochTimestamp(__expectNumber(_))),
        Location: __expectString,
        Protocol: __expectString,
        Status: __expectString,
        UserId: __expectString,
    });
};
const de_StreamSessionSummaryList = (output, context) => {
    const retVal = (output || [])
        .filter((e) => e != null)
        .map((entry) => {
        return de_StreamSessionSummary(entry, context);
    });
    return retVal;
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => collectBody(streamBody, context).then((body) => context.utf8Encoder(body));
const _EFS = "ExportFilesStatus";
const _L = "Locations";
const _MR = "MaxResults";
const _NT = "NextToken";
const _S = "Status";
const _TK = "TagKeys";
const _l = "locations";
const _tK = "tagKeys";
