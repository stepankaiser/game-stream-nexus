import { checkExceptions, createWaiter, WaiterState } from "@smithy/util-waiter";
import { GetApplicationCommand } from "../commands/GetApplicationCommand";
const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetApplicationCommand(input));
        reason = result;
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: WaiterState.SUCCESS, reason };
        }
    }
    return { state: WaiterState.RETRY, reason };
};
export const waitForApplicationDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
export const waitUntilApplicationDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return checkExceptions(result);
};
