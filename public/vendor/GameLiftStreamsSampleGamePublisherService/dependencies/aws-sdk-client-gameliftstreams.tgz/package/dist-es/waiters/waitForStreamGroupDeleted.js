import { checkExceptions, createWaiter, WaiterState } from "@smithy/util-waiter";
import { GetStreamGroupCommand } from "../commands/GetStreamGroupCommand";
const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetStreamGroupCommand(input));
        reason = result;
    }
    catch (exception) {
        reason = exception;
        if (exception.name && exception.name == "ResourceNotFoundException") {
            return { state: WaiterState.SUCCESS, reason };
        }
    }
    return { state: WaiterState.RETRY, reason };
};
export const waitForStreamGroupDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 30, maxDelay: 1800 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
export const waitUntilStreamGroupDeleted = async (params, input) => {
    const serviceDefaults = { minDelay: 30, maxDelay: 1800 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return checkExceptions(result);
};
