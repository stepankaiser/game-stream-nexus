import { checkExceptions, createWaiter, WaiterState } from "@smithy/util-waiter";
import { GetStreamSessionCommand } from "../commands/GetStreamSessionCommand";
const checkState = async (client, input) => {
    let reason;
    try {
        const result = await client.send(new GetStreamSessionCommand(input));
        reason = result;
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "ACTIVE") {
                return { state: WaiterState.SUCCESS, reason };
            }
        }
        catch (e) { }
        try {
            const returnComparator = () => {
                return result.Status;
            };
            if (returnComparator() === "ERROR") {
                return { state: WaiterState.FAILURE, reason };
            }
        }
        catch (e) { }
    }
    catch (exception) {
        reason = exception;
    }
    return { state: WaiterState.RETRY, reason };
};
export const waitForStreamSessionActive = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    return createWaiter({ ...serviceDefaults, ...params }, input, checkState);
};
export const waitUntilStreamSessionActive = async (params, input) => {
    const serviceDefaults = { minDelay: 2, maxDelay: 120 };
    const result = await createWaiter({ ...serviceDefaults, ...params }, input, checkState);
    return checkExceptions(result);
};
