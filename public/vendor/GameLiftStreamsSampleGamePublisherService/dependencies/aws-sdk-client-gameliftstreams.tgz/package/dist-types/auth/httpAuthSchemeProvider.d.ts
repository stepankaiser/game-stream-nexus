import { AwsSdkSigV4AuthInputConfig, AwsSdkSigV4AuthResolvedConfig, AwsSdkSigV4PreviouslyResolved } from "@aws-sdk/core";
import { HandlerExecutionContext, HttpAuthScheme, HttpAuthSchemeParameters, HttpAuthSchemeParametersProvider, HttpAuthSchemeProvider } from "@smithy/types";
import { GameLiftStreamsClientResolvedConfig } from "../GameLiftStreamsClient";
/**
 * @internal
 */
export interface GameLiftStreamsHttpAuthSchemeParameters extends HttpAuthSchemeParameters {
    region?: string;
}
/**
 * @internal
 */
export interface GameLiftStreamsHttpAuthSchemeParametersProvider extends HttpAuthSchemeParametersProvider<GameLiftStreamsClientResolvedConfig, HandlerExecutionContext, GameLiftStreamsHttpAuthSchemeParameters, object> {
}
/**
 * @internal
 */
export declare const defaultGameLiftStreamsHttpAuthSchemeParametersProvider: (config: GameLiftStreamsClientResolvedConfig, context: HandlerExecutionContext, input: object) => Promise<GameLiftStreamsHttpAuthSchemeParameters>;
/**
 * @internal
 */
export interface GameLiftStreamsHttpAuthSchemeProvider extends HttpAuthSchemeProvider<GameLiftStreamsHttpAuthSchemeParameters> {
}
/**
 * @internal
 */
export declare const defaultGameLiftStreamsHttpAuthSchemeProvider: GameLiftStreamsHttpAuthSchemeProvider;
/**
 * @internal
 */
export interface HttpAuthSchemeInputConfig extends AwsSdkSigV4AuthInputConfig {
    /**
     * Configuration of HttpAuthSchemes for a client which provides default identity providers and signers per auth scheme.
     * @internal
     */
    httpAuthSchemes?: HttpAuthScheme[];
    /**
     * Configuration of an HttpAuthSchemeProvider for a client which resolves which HttpAuthScheme to use.
     * @internal
     */
    httpAuthSchemeProvider?: GameLiftStreamsHttpAuthSchemeProvider;
}
/**
 * @internal
 */
export interface HttpAuthSchemeResolvedConfig extends AwsSdkSigV4AuthResolvedConfig {
    /**
     * Configuration of HttpAuthSchemes for a client which provides default identity providers and signers per auth scheme.
     * @internal
     */
    readonly httpAuthSchemes: HttpAuthScheme[];
    /**
     * Configuration of an HttpAuthSchemeProvider for a client which resolves which HttpAuthScheme to use.
     * @internal
     */
    readonly httpAuthSchemeProvider: GameLiftStreamsHttpAuthSchemeProvider;
}
/**
 * @internal
 */
export declare const resolveHttpAuthSchemeConfig: <T>(config: T & HttpAuthSchemeInputConfig & AwsSdkSigV4PreviouslyResolved) => T & HttpAuthSchemeResolvedConfig;
