import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../GameLiftStreamsClient";
import { DeleteStreamGroupInput } from "../models/models_0";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link DeleteStreamGroupCommand}.
 */
export interface DeleteStreamGroupCommandInput extends DeleteStreamGroupInput {
}
/**
 * @public
 *
 * The output of {@link DeleteStreamGroupCommand}.
 */
export interface DeleteStreamGroupCommandOutput extends __MetadataBearer {
}
declare const DeleteStreamGroupCommand_base: {
    new (input: DeleteStreamGroupCommandInput): import("@smithy/smithy-client").CommandImpl<DeleteStreamGroupCommandInput, DeleteStreamGroupCommandOutput, GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: DeleteStreamGroupCommandInput): import("@smithy/smithy-client").CommandImpl<DeleteStreamGroupCommandInput, DeleteStreamGroupCommandOutput, GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * <p>Permanently deletes all compute resources and information related to a stream group. To delete a stream group, specify the unique stream
 *             group identifier. During the deletion process, the stream group's status is <code>DELETING</code>. This operation stops streams in
 *             progress and prevents new streams from starting. As a best practice, before deleting the stream group, call <a>ListStreamSessions</a> to check for streams in progress and take action to stop them. When you delete a stream group, any
 *             application associations referring to that stream group are automatically removed.</p>
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { GameLiftStreamsClient, DeleteStreamGroupCommand } from "@aws-sdk/client-gameliftstreams"; // ES Modules import
 * // const { GameLiftStreamsClient, DeleteStreamGroupCommand } = require("@aws-sdk/client-gameliftstreams"); // CommonJS import
 * const client = new GameLiftStreamsClient(config);
 * const input = { // DeleteStreamGroupInput
 *   Identifier: "STRING_VALUE", // required
 * };
 * const command = new DeleteStreamGroupCommand(input);
 * const response = await client.send(command);
 * // {};
 *
 * ```
 *
 * @param DeleteStreamGroupCommandInput - {@link DeleteStreamGroupCommandInput}
 * @returns {@link DeleteStreamGroupCommandOutput}
 * @see {@link DeleteStreamGroupCommandInput} for command's `input` shape.
 * @see {@link DeleteStreamGroupCommandOutput} for command's `response` shape.
 * @see {@link GameLiftStreamsClientResolvedConfig | config} for GameLiftStreamsClient's `config` shape.
 *
 * @throws {@link AccessDeniedException} (client fault)
 *  <p>You don't have the required permissions to access this Amazon GameLift Streams resource. Correct the
 *          permissions before you try again.</p>
 *
 * @throws {@link ConflictException} (client fault)
 *  <p>The requested operation would cause a conflict with the current state of a service resource associated with the request. Resolve the conflict before retrying this request.</p>
 *
 * @throws {@link InternalServerException} (server fault)
 *  <p>The service encountered an internal error and is unable to complete the request.</p>
 *
 * @throws {@link ResourceNotFoundException} (client fault)
 *  <p>The resource specified in the request was not found. Correct the request before you try again.</p>
 *
 * @throws {@link ThrottlingException} (client fault)
 *  <p>The request was denied due to request throttling. Retry the request after the
 *          suggested wait time.</p>
 *
 * @throws {@link ValidationException} (client fault)
 *  <p>One or more parameter values in the request fail to satisfy the specified constraints.
 *          Correct the invalid parameter values before retrying the request.</p>
 *
 * @throws {@link GameLiftStreamsServiceException}
 * <p>Base exception class for all service exceptions from GameLiftStreams service.</p>
 *
 * @public
 */
export declare class DeleteStreamGroupCommand extends DeleteStreamGroupCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: DeleteStreamGroupInput;
            output: {};
        };
        sdk: {
            input: DeleteStreamGroupCommandInput;
            output: DeleteStreamGroupCommandOutput;
        };
    };
}
