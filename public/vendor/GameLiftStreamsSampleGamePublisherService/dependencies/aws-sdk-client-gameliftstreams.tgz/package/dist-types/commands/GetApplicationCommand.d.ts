import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../GameLiftStreamsClient";
import { GetApplicationInput, GetApplicationOutput } from "../models/models_0";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetApplicationCommand}.
 */
export interface GetApplicationCommandInput extends GetApplicationInput {
}
/**
 * @public
 *
 * The output of {@link GetApplicationCommand}.
 */
export interface GetApplicationCommandOutput extends GetApplicationOutput, __MetadataBearer {
}
declare const GetApplicationCommand_base: {
    new (input: GetApplicationCommandInput): import("@smithy/smithy-client").CommandImpl<GetApplicationCommandInput, GetApplicationCommandOutput, GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: GetApplicationCommandInput): import("@smithy/smithy-client").CommandImpl<GetApplicationCommandInput, GetApplicationCommandOutput, GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * <p>Retrieves properties for an Amazon GameLift Streams application resource. Specify the ID of the
 *             application that you want to retrieve. If the operation is successful, it returns
 *             properties for the requested application.</p>
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { GameLiftStreamsClient, GetApplicationCommand } from "@aws-sdk/client-gameliftstreams"; // ES Modules import
 * // const { GameLiftStreamsClient, GetApplicationCommand } = require("@aws-sdk/client-gameliftstreams"); // CommonJS import
 * const client = new GameLiftStreamsClient(config);
 * const input = { // GetApplicationInput
 *   Identifier: "STRING_VALUE", // required
 * };
 * const command = new GetApplicationCommand(input);
 * const response = await client.send(command);
 * // { // GetApplicationOutput
 * //   Arn: "STRING_VALUE", // required
 * //   Description: "STRING_VALUE",
 * //   RuntimeEnvironment: { // RuntimeEnvironment
 * //     Type: "PROTON" || "WINDOWS" || "UBUNTU", // required
 * //     Version: "STRING_VALUE", // required
 * //   },
 * //   ExecutablePath: "STRING_VALUE",
 * //   ApplicationLogPaths: [ // FilePaths
 * //     "STRING_VALUE",
 * //   ],
 * //   ApplicationLogOutputUri: "STRING_VALUE",
 * //   ApplicationSourceUri: "STRING_VALUE",
 * //   Id: "STRING_VALUE",
 * //   Status: "INITIALIZED" || "PROCESSING" || "READY" || "DELETING" || "ERROR",
 * //   StatusReason: "internalError" || "accessDenied",
 * //   ReplicationStatuses: [ // ReplicationStatuses
 * //     { // ReplicationStatus
 * //       Location: "STRING_VALUE",
 * //       Status: "REPLICATING" || "COMPLETED",
 * //     },
 * //   ],
 * //   CreatedAt: new Date("TIMESTAMP"),
 * //   LastUpdatedAt: new Date("TIMESTAMP"),
 * //   AssociatedStreamGroups: [ // ArnList
 * //     "STRING_VALUE",
 * //   ],
 * // };
 *
 * ```
 *
 * @param GetApplicationCommandInput - {@link GetApplicationCommandInput}
 * @returns {@link GetApplicationCommandOutput}
 * @see {@link GetApplicationCommandInput} for command's `input` shape.
 * @see {@link GetApplicationCommandOutput} for command's `response` shape.
 * @see {@link GameLiftStreamsClientResolvedConfig | config} for GameLiftStreamsClient's `config` shape.
 *
 * @throws {@link AccessDeniedException} (client fault)
 *  <p>You don't have the required permissions to access this Amazon GameLift Streams resource. Correct the
 *          permissions before you try again.</p>
 *
 * @throws {@link InternalServerException} (server fault)
 *  <p>The service encountered an internal error and is unable to complete the request.</p>
 *
 * @throws {@link ResourceNotFoundException} (client fault)
 *  <p>The resource specified in the request was not found. Correct the request before you try again.</p>
 *
 * @throws {@link ThrottlingException} (client fault)
 *  <p>The request was denied due to request throttling. Retry the request after the
 *          suggested wait time.</p>
 *
 * @throws {@link ValidationException} (client fault)
 *  <p>One or more parameter values in the request fail to satisfy the specified constraints.
 *          Correct the invalid parameter values before retrying the request.</p>
 *
 * @throws {@link GameLiftStreamsServiceException}
 * <p>Base exception class for all service exceptions from GameLiftStreams service.</p>
 *
 * @public
 */
export declare class GetApplicationCommand extends GetApplicationCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetApplicationInput;
            output: GetApplicationOutput;
        };
        sdk: {
            input: GetApplicationCommandInput;
            output: GetApplicationCommandOutput;
        };
    };
}
