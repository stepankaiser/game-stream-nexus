import { Command as $Command } from "@smithy/smithy-client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../GameLiftStreamsClient";
import { GetStreamGroupInput, GetStreamGroupOutput } from "../models/models_0";
/**
 * @public
 */
export type { __MetadataBearer };
export { $Command };
/**
 * @public
 *
 * The input for {@link GetStreamGroupCommand}.
 */
export interface GetStreamGroupCommandInput extends GetStreamGroupInput {
}
/**
 * @public
 *
 * The output of {@link GetStreamGroupCommand}.
 */
export interface GetStreamGroupCommandOutput extends GetStreamGroupOutput, __MetadataBearer {
}
declare const GetStreamGroupCommand_base: {
    new (input: GetStreamGroupCommandInput): import("@smithy/smithy-client").CommandImpl<GetStreamGroupCommandInput, GetStreamGroupCommandOutput, GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    new (__0_0: GetStreamGroupCommandInput): import("@smithy/smithy-client").CommandImpl<GetStreamGroupCommandInput, GetStreamGroupCommandOutput, GameLiftStreamsClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes>;
    getEndpointParameterInstructions(): import("@smithy/middleware-endpoint").EndpointParameterInstructions;
};
/**
 * <p>Retrieves properties for a Amazon GameLift Streams stream group resource. Specify the ID of the stream
 *             group that you want to retrieve. If the operation is successful, it returns properties
 *             for the requested stream group.</p>
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { GameLiftStreamsClient, GetStreamGroupCommand } from "@aws-sdk/client-gameliftstreams"; // ES Modules import
 * // const { GameLiftStreamsClient, GetStreamGroupCommand } = require("@aws-sdk/client-gameliftstreams"); // CommonJS import
 * const client = new GameLiftStreamsClient(config);
 * const input = { // GetStreamGroupInput
 *   Identifier: "STRING_VALUE", // required
 * };
 * const command = new GetStreamGroupCommand(input);
 * const response = await client.send(command);
 * // { // GetStreamGroupOutput
 * //   Arn: "STRING_VALUE", // required
 * //   Description: "STRING_VALUE",
 * //   DefaultApplication: { // DefaultApplication
 * //     Id: "STRING_VALUE",
 * //     Arn: "STRING_VALUE",
 * //   },
 * //   LocationStates: [ // LocationStates
 * //     { // LocationState
 * //       LocationName: "STRING_VALUE",
 * //       Status: "ACTIVATING" || "ACTIVE" || "ERROR" || "REMOVING",
 * //       AlwaysOnCapacity: Number("int"),
 * //       OnDemandCapacity: Number("int"),
 * //       RequestedCapacity: Number("int"),
 * //       AllocatedCapacity: Number("int"),
 * //       IdleCapacity: Number("int"),
 * //     },
 * //   ],
 * //   StreamClass: "gen4n_high" || "gen4n_ultra" || "gen4n_win2022" || "gen5n_high" || "gen5n_ultra" || "gen5n_win2022",
 * //   Id: "STRING_VALUE",
 * //   Status: "ACTIVATING" || "UPDATING_LOCATIONS" || "ACTIVE" || "ACTIVE_WITH_ERRORS" || "ERROR" || "DELETING",
 * //   StatusReason: "internalError" || "noAvailableInstances",
 * //   LastUpdatedAt: new Date("TIMESTAMP"),
 * //   CreatedAt: new Date("TIMESTAMP"),
 * //   AssociatedApplications: [ // ArnList
 * //     "STRING_VALUE",
 * //   ],
 * // };
 *
 * ```
 *
 * @param GetStreamGroupCommandInput - {@link GetStreamGroupCommandInput}
 * @returns {@link GetStreamGroupCommandOutput}
 * @see {@link GetStreamGroupCommandInput} for command's `input` shape.
 * @see {@link GetStreamGroupCommandOutput} for command's `response` shape.
 * @see {@link GameLiftStreamsClientResolvedConfig | config} for GameLiftStreamsClient's `config` shape.
 *
 * @throws {@link AccessDeniedException} (client fault)
 *  <p>You don't have the required permissions to access this Amazon GameLift Streams resource. Correct the
 *          permissions before you try again.</p>
 *
 * @throws {@link InternalServerException} (server fault)
 *  <p>The service encountered an internal error and is unable to complete the request.</p>
 *
 * @throws {@link ResourceNotFoundException} (client fault)
 *  <p>The resource specified in the request was not found. Correct the request before you try again.</p>
 *
 * @throws {@link ThrottlingException} (client fault)
 *  <p>The request was denied due to request throttling. Retry the request after the
 *          suggested wait time.</p>
 *
 * @throws {@link ValidationException} (client fault)
 *  <p>One or more parameter values in the request fail to satisfy the specified constraints.
 *          Correct the invalid parameter values before retrying the request.</p>
 *
 * @throws {@link GameLiftStreamsServiceException}
 * <p>Base exception class for all service exceptions from GameLiftStreams service.</p>
 *
 * @public
 */
export declare class GetStreamGroupCommand extends GetStreamGroupCommand_base {
    /** @internal type navigation helper, not in runtime. */
    protected static __types: {
        api: {
            input: GetStreamGroupInput;
            output: GetStreamGroupOutput;
        };
        sdk: {
            input: GetStreamGroupCommandInput;
            output: GetStreamGroupCommandOutput;
        };
    };
}
