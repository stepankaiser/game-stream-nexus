import { Paginator } from "@smithy/types";
import { ListApplicationsCommandInput, ListApplicationsCommandOutput } from "../commands/ListApplicationsCommand";
import { GameLiftStreamsPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListApplications: (config: GameLiftStreamsPaginationConfiguration, input: ListApplicationsCommandInput, ...rest: any[]) => Paginator<ListApplicationsCommandOutput>;
