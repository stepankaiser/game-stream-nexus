import { Paginator } from "@smithy/types";
import { ListStreamGroupsCommandInput, ListStreamGroupsCommandOutput } from "../commands/ListStreamGroupsCommand";
import { GameLiftStreamsPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListStreamGroups: (config: GameLiftStreamsPaginationConfiguration, input: ListStreamGroupsCommandInput, ...rest: any[]) => Paginator<ListStreamGroupsCommandOutput>;
