import { Paginator } from "@smithy/types";
import { ListStreamSessionsByAccountCommandInput, ListStreamSessionsByAccountCommandOutput } from "../commands/ListStreamSessionsByAccountCommand";
import { GameLiftStreamsPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListStreamSessionsByAccount: (config: GameLiftStreamsPaginationConfiguration, input: ListStreamSessionsByAccountCommandInput, ...rest: any[]) => Paginator<ListStreamSessionsByAccountCommandOutput>;
