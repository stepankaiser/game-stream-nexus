import { Paginator } from "@smithy/types";
import { ListStreamSessionsCommandInput, ListStreamSessionsCommandOutput } from "../commands/ListStreamSessionsCommand";
import { GameLiftStreamsPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListStreamSessions: (config: GameLiftStreamsPaginationConfiguration, input: ListStreamSessionsCommandInput, ...rest: any[]) => Paginator<ListStreamSessionsCommandOutput>;
