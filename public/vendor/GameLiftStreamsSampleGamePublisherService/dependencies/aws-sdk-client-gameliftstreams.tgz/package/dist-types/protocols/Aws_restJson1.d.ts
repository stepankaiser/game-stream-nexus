import { HttpRequest as __HttpRequest, HttpResponse as __HttpResponse } from "@smithy/protocol-http";
import { SerdeContext as __SerdeContext } from "@smithy/types";
import { AddStreamGroupLocationsCommandInput, AddStreamGroupLocationsCommandOutput } from "../commands/AddStreamGroupLocationsCommand";
import { AssociateApplicationsCommandInput, AssociateApplicationsCommandOutput } from "../commands/AssociateApplicationsCommand";
import { CreateApplicationCommandInput, CreateApplicationCommandOutput } from "../commands/CreateApplicationCommand";
import { CreateStreamGroupCommandInput, CreateStreamGroupCommandOutput } from "../commands/CreateStreamGroupCommand";
import { CreateStreamSessionConnectionCommandInput, CreateStreamSessionConnectionCommandOutput } from "../commands/CreateStreamSessionConnectionCommand";
import { DeleteApplicationCommandInput, DeleteApplicationCommandOutput } from "../commands/DeleteApplicationCommand";
import { DeleteStreamGroupCommandInput, DeleteStreamGroupCommandOutput } from "../commands/DeleteStreamGroupCommand";
import { DisassociateApplicationsCommandInput, DisassociateApplicationsCommandOutput } from "../commands/DisassociateApplicationsCommand";
import { ExportStreamSessionFilesCommandInput, ExportStreamSessionFilesCommandOutput } from "../commands/ExportStreamSessionFilesCommand";
import { GetApplicationCommandInput, GetApplicationCommandOutput } from "../commands/GetApplicationCommand";
import { GetStreamGroupCommandInput, GetStreamGroupCommandOutput } from "../commands/GetStreamGroupCommand";
import { GetStreamSessionCommandInput, GetStreamSessionCommandOutput } from "../commands/GetStreamSessionCommand";
import { ListApplicationsCommandInput, ListApplicationsCommandOutput } from "../commands/ListApplicationsCommand";
import { ListStreamGroupsCommandInput, ListStreamGroupsCommandOutput } from "../commands/ListStreamGroupsCommand";
import { ListStreamSessionsByAccountCommandInput, ListStreamSessionsByAccountCommandOutput } from "../commands/ListStreamSessionsByAccountCommand";
import { ListStreamSessionsCommandInput, ListStreamSessionsCommandOutput } from "../commands/ListStreamSessionsCommand";
import { ListTagsForResourceCommandInput, ListTagsForResourceCommandOutput } from "../commands/ListTagsForResourceCommand";
import { RemoveStreamGroupLocationsCommandInput, RemoveStreamGroupLocationsCommandOutput } from "../commands/RemoveStreamGroupLocationsCommand";
import { StartStreamSessionCommandInput, StartStreamSessionCommandOutput } from "../commands/StartStreamSessionCommand";
import { TagResourceCommandInput, TagResourceCommandOutput } from "../commands/TagResourceCommand";
import { TerminateStreamSessionCommandInput, TerminateStreamSessionCommandOutput } from "../commands/TerminateStreamSessionCommand";
import { UntagResourceCommandInput, UntagResourceCommandOutput } from "../commands/UntagResourceCommand";
import { UpdateApplicationCommandInput, UpdateApplicationCommandOutput } from "../commands/UpdateApplicationCommand";
import { UpdateStreamGroupCommandInput, UpdateStreamGroupCommandOutput } from "../commands/UpdateStreamGroupCommand";
/**
 * serializeAws_restJson1AddStreamGroupLocationsCommand
 */
export declare const se_AddStreamGroupLocationsCommand: (input: AddStreamGroupLocationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1AssociateApplicationsCommand
 */
export declare const se_AssociateApplicationsCommand: (input: AssociateApplicationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreateApplicationCommand
 */
export declare const se_CreateApplicationCommand: (input: CreateApplicationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreateStreamGroupCommand
 */
export declare const se_CreateStreamGroupCommand: (input: CreateStreamGroupCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1CreateStreamSessionConnectionCommand
 */
export declare const se_CreateStreamSessionConnectionCommand: (input: CreateStreamSessionConnectionCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DeleteApplicationCommand
 */
export declare const se_DeleteApplicationCommand: (input: DeleteApplicationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DeleteStreamGroupCommand
 */
export declare const se_DeleteStreamGroupCommand: (input: DeleteStreamGroupCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1DisassociateApplicationsCommand
 */
export declare const se_DisassociateApplicationsCommand: (input: DisassociateApplicationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ExportStreamSessionFilesCommand
 */
export declare const se_ExportStreamSessionFilesCommand: (input: ExportStreamSessionFilesCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetApplicationCommand
 */
export declare const se_GetApplicationCommand: (input: GetApplicationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetStreamGroupCommand
 */
export declare const se_GetStreamGroupCommand: (input: GetStreamGroupCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetStreamSessionCommand
 */
export declare const se_GetStreamSessionCommand: (input: GetStreamSessionCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListApplicationsCommand
 */
export declare const se_ListApplicationsCommand: (input: ListApplicationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListStreamGroupsCommand
 */
export declare const se_ListStreamGroupsCommand: (input: ListStreamGroupsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListStreamSessionsCommand
 */
export declare const se_ListStreamSessionsCommand: (input: ListStreamSessionsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListStreamSessionsByAccountCommand
 */
export declare const se_ListStreamSessionsByAccountCommand: (input: ListStreamSessionsByAccountCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ListTagsForResourceCommand
 */
export declare const se_ListTagsForResourceCommand: (input: ListTagsForResourceCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1RemoveStreamGroupLocationsCommand
 */
export declare const se_RemoveStreamGroupLocationsCommand: (input: RemoveStreamGroupLocationsCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1StartStreamSessionCommand
 */
export declare const se_StartStreamSessionCommand: (input: StartStreamSessionCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1TagResourceCommand
 */
export declare const se_TagResourceCommand: (input: TagResourceCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1TerminateStreamSessionCommand
 */
export declare const se_TerminateStreamSessionCommand: (input: TerminateStreamSessionCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1UntagResourceCommand
 */
export declare const se_UntagResourceCommand: (input: UntagResourceCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1UpdateApplicationCommand
 */
export declare const se_UpdateApplicationCommand: (input: UpdateApplicationCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1UpdateStreamGroupCommand
 */
export declare const se_UpdateStreamGroupCommand: (input: UpdateStreamGroupCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * deserializeAws_restJson1AddStreamGroupLocationsCommand
 */
export declare const de_AddStreamGroupLocationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<AddStreamGroupLocationsCommandOutput>;
/**
 * deserializeAws_restJson1AssociateApplicationsCommand
 */
export declare const de_AssociateApplicationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<AssociateApplicationsCommandOutput>;
/**
 * deserializeAws_restJson1CreateApplicationCommand
 */
export declare const de_CreateApplicationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateApplicationCommandOutput>;
/**
 * deserializeAws_restJson1CreateStreamGroupCommand
 */
export declare const de_CreateStreamGroupCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateStreamGroupCommandOutput>;
/**
 * deserializeAws_restJson1CreateStreamSessionConnectionCommand
 */
export declare const de_CreateStreamSessionConnectionCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<CreateStreamSessionConnectionCommandOutput>;
/**
 * deserializeAws_restJson1DeleteApplicationCommand
 */
export declare const de_DeleteApplicationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteApplicationCommandOutput>;
/**
 * deserializeAws_restJson1DeleteStreamGroupCommand
 */
export declare const de_DeleteStreamGroupCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DeleteStreamGroupCommandOutput>;
/**
 * deserializeAws_restJson1DisassociateApplicationsCommand
 */
export declare const de_DisassociateApplicationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<DisassociateApplicationsCommandOutput>;
/**
 * deserializeAws_restJson1ExportStreamSessionFilesCommand
 */
export declare const de_ExportStreamSessionFilesCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ExportStreamSessionFilesCommandOutput>;
/**
 * deserializeAws_restJson1GetApplicationCommand
 */
export declare const de_GetApplicationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetApplicationCommandOutput>;
/**
 * deserializeAws_restJson1GetStreamGroupCommand
 */
export declare const de_GetStreamGroupCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetStreamGroupCommandOutput>;
/**
 * deserializeAws_restJson1GetStreamSessionCommand
 */
export declare const de_GetStreamSessionCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetStreamSessionCommandOutput>;
/**
 * deserializeAws_restJson1ListApplicationsCommand
 */
export declare const de_ListApplicationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListApplicationsCommandOutput>;
/**
 * deserializeAws_restJson1ListStreamGroupsCommand
 */
export declare const de_ListStreamGroupsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStreamGroupsCommandOutput>;
/**
 * deserializeAws_restJson1ListStreamSessionsCommand
 */
export declare const de_ListStreamSessionsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStreamSessionsCommandOutput>;
/**
 * deserializeAws_restJson1ListStreamSessionsByAccountCommand
 */
export declare const de_ListStreamSessionsByAccountCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListStreamSessionsByAccountCommandOutput>;
/**
 * deserializeAws_restJson1ListTagsForResourceCommand
 */
export declare const de_ListTagsForResourceCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ListTagsForResourceCommandOutput>;
/**
 * deserializeAws_restJson1RemoveStreamGroupLocationsCommand
 */
export declare const de_RemoveStreamGroupLocationsCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<RemoveStreamGroupLocationsCommandOutput>;
/**
 * deserializeAws_restJson1StartStreamSessionCommand
 */
export declare const de_StartStreamSessionCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<StartStreamSessionCommandOutput>;
/**
 * deserializeAws_restJson1TagResourceCommand
 */
export declare const de_TagResourceCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<TagResourceCommandOutput>;
/**
 * deserializeAws_restJson1TerminateStreamSessionCommand
 */
export declare const de_TerminateStreamSessionCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<TerminateStreamSessionCommandOutput>;
/**
 * deserializeAws_restJson1UntagResourceCommand
 */
export declare const de_UntagResourceCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UntagResourceCommandOutput>;
/**
 * deserializeAws_restJson1UpdateApplicationCommand
 */
export declare const de_UpdateApplicationCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateApplicationCommandOutput>;
/**
 * deserializeAws_restJson1UpdateStreamGroupCommand
 */
export declare const de_UpdateStreamGroupCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<UpdateStreamGroupCommandOutput>;
