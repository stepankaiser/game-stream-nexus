import { WaiterConfiguration, WaiterResult } from "@smithy/util-waiter";
import { GetApplicationCommandInput } from "../commands/GetApplicationCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
/**
 * Waits until an application is deleted
 *  @deprecated Use waitUntilApplicationDeleted instead. waitForApplicationDeleted does not throw error in non-success cases.
 */
export declare const waitForApplicationDeleted: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetApplicationCommandInput) => Promise<WaiterResult>;
/**
 * Waits until an application is deleted
 *  @param params - Waiter configuration options.
 *  @param input - The input to GetApplicationCommand for polling.
 */
export declare const waitUntilApplicationDeleted: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetApplicationCommandInput) => Promise<WaiterResult>;
