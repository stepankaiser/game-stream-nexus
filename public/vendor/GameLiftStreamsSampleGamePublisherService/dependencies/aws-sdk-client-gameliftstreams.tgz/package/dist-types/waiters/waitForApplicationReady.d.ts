import { WaiterConfiguration, WaiterResult } from "@smithy/util-waiter";
import { GetApplicationCommandInput } from "../commands/GetApplicationCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
/**
 * Waits until an application is ready
 *  @deprecated Use waitUntilApplicationReady instead. waitForApplicationReady does not throw error in non-success cases.
 */
export declare const waitForApplicationReady: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetApplicationCommandInput) => Promise<WaiterResult>;
/**
 * Waits until an application is ready
 *  @param params - Waiter configuration options.
 *  @param input - The input to GetApplicationCommand for polling.
 */
export declare const waitUntilApplicationReady: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetApplicationCommandInput) => Promise<WaiterResult>;
