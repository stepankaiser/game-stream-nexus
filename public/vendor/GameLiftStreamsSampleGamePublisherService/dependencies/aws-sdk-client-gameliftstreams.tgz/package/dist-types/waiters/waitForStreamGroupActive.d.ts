import { WaiterConfiguration, WaiterResult } from "@smithy/util-waiter";
import { GetStreamGroupCommandInput } from "../commands/GetStreamGroupCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
/**
 * Waits until a stream group is active
 *  @deprecated Use waitUntilStreamGroupActive instead. waitForStreamGroupActive does not throw error in non-success cases.
 */
export declare const waitForStreamGroupActive: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetStreamGroupCommandInput) => Promise<WaiterResult>;
/**
 * Waits until a stream group is active
 *  @param params - Waiter configuration options.
 *  @param input - The input to GetStreamGroupCommand for polling.
 */
export declare const waitUntilStreamGroupActive: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetStreamGroupCommandInput) => Promise<WaiterResult>;
