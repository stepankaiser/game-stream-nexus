import { WaiterConfiguration, WaiterResult } from "@smithy/util-waiter";
import { GetStreamGroupCommandInput } from "../commands/GetStreamGroupCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
/**
 * Waits until a stream group is deleted
 *  @deprecated Use waitUntilStreamGroupDeleted instead. waitForStreamGroupDeleted does not throw error in non-success cases.
 */
export declare const waitForStreamGroupDeleted: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetStreamGroupCommandInput) => Promise<WaiterResult>;
/**
 * Waits until a stream group is deleted
 *  @param params - Waiter configuration options.
 *  @param input - The input to GetStreamGroupCommand for polling.
 */
export declare const waitUntilStreamGroupDeleted: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetStreamGroupCommandInput) => Promise<WaiterResult>;
