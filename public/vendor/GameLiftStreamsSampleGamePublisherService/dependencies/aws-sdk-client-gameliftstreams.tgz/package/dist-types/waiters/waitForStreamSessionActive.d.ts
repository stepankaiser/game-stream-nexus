import { WaiterConfiguration, WaiterResult } from "@smithy/util-waiter";
import { GetStreamSessionCommandInput } from "../commands/GetStreamSessionCommand";
import { GameLiftStreamsClient } from "../GameLiftStreamsClient";
/**
 * Waits until a stream session is active
 *  @deprecated Use waitUntilStreamSessionActive instead. waitForStreamSessionActive does not throw error in non-success cases.
 */
export declare const waitForStreamSessionActive: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetStreamSessionCommandInput) => Promise<WaiterResult>;
/**
 * Waits until a stream session is active
 *  @param params - Waiter configuration options.
 *  @param input - The input to GetStreamSessionCommand for polling.
 */
export declare const waitUntilStreamSessionActive: (params: WaiterConfiguration<GameLiftStreamsClient>, input: GetStreamSessionCommandInput) => Promise<WaiterResult>;
